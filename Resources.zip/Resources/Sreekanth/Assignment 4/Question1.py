import random
import binascii

def misra_gries(file_location, k):
    with open(file_location) as file:
        contents = file.read()
        contents = list(contents)
        counter = [0]*(k)
        labels = [None]*(k)
        m = len(contents)
        for a in contents:
            if(a in labels):
                idx = labels.index(a)
                counter[idx] = counter[idx]+1
            else:
                if(0 in counter):
                    idx = counter.index(0)
                    counter[idx] = 1
                    labels[idx] = a
                else:
                    counter = [item-1 for item in counter]

        return set(zip(counter, labels))

def pickRandomCoeffs(k):
  randList = []
  while k > 0:
    randIndex = random.randint(0, 2**32-1)
    while randIndex in randList:
      randIndex = random.randint(0, 2**32-1)
    randList.append(randIndex)
    k = k - 1
  return randList

def count_min(file_location, k, t):
    with open(file_location) as file:
        contents = file.read()
        contents = list(contents)
        coeffA = pickRandomCoeffs(t)
        coeffB = pickRandomCoeffs(t)
        c = [{} for _ in range(t)]
        for a in contents:
            for i in range(0, t):
                crc = binascii.crc32(a.encode()) & 0xffffffff
                hashCode = (coeffA[i] * crc + coeffB[i]) % 10
                if hashCode in c[i]:
                    c[i][hashCode] = c[i][hashCode] + 1
                else:
                    c[i][hashCode] = 1
        for a in ['a', 'b', 'c']:
            min = 2**31-1
            for i in range(0, t):
                crc = binascii.crc32(a.encode()) & 0xffffffff
                hashCode = (coeffA[i] * crc + coeffB[i]) % 10
                temp = c[i][hashCode]
                if(temp< min):
                    min = temp
            print("count for "+a+" is "+ str(min))

# print(misra_gries("S2.txt", 9))
count_min("S2.txt", 10, 5)