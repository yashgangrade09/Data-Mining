import sys
import math
import numpy as np
import matplotlib.pyplot as plt

def ecdf(data):
    """Compute ECDF for a one-dimensional array of measurements."""

    # Number of data points: n
    n = len(data)

    # x-data for the ECDF: x
    x = np.sort(data)

    # y-data for the ECDF: y
    y = np.arange(1, n+1) / n

    return x, y

def plot_clusters(colors, clusters, centers):
    cluster_list = []

    for key, value in clusters.items():
        cluster_list.append(value)

    for i in range(len(cluster_list)):
        cluster = cluster_list[i]

        x = []
        y = []

        for point in cluster:
            x.append(point[0])
            y.append(point[1])

        plt.plot(x, y, marker='.', linestyle='none', color=colors[i])

    # for center in centers:
    #     plt.plot(center[0], center[1], marker='.', linestyle='none', color='black')

def distance(c, x):
    sum = 0
    for i in range(len(c)):
        sum = sum + (c[i] - x[i]) ** 2

    return math.sqrt(sum)

def phi_c_x(centers, x):
    shortest_distance = sys.maxsize
    candidate_c = None

    for c in centers:
        distance_c_x = distance(c, x)
        if distance_c_x < shortest_distance:
            shortest_distance = distance_c_x
            candidate_c = c

    return candidate_c;

def get_centers(points, k):
    centers = []

    center_1_index = np.random.randint(0, len(points))
    centers.append(points[0])

    # print(centers)

    for i in range(1, k):

        distance_array = []

        for point in points:
            distance_x = distance(point, phi_c_x(centers, point))
            distance_array.append(distance_x)

        sum_distance = np.sum(distance_array)
        distance_array = [distance / sum_distance for distance in distance_array]

        center_index = np.random.choice(len(points), 1, distance_array)

        centers.append(points[center_index[0]])

    return centers

def get_clusters(centers, points):

    clusters_dict = {}

    for point in points:
        center_x = phi_c_x(centers, point)
        key = str(center_x[0]) + str(center_x[1])

        if key in clusters_dict.keys():
            clusters_dict[key].append(point)
        else:
            clusters_dict[key] = [point]

    clusters_list = []
    for key, value in clusters_dict.items():
        clusters_list.append(value)

    return clusters_dict, clusters_list;

def get_cost(centers, points):

    sum = 0

    for point in points:
        center_x = phi_c_x(centers, point)
        distance_x = distance(point, center_x)
        sum = sum + distance_x ** 2

    k_means_cost = math.sqrt(sum / len(points))

    return k_means_cost

def get_centers_kmeans(points, k):
    centers = []

    center_1_index = np.random.randint(0, len(points))
    centers.append(points[center_1_index])

    for i in range(1, k):

        distance_array = []

        for point in points:
            distance_x = distance(point, phi_c_x(centers, point))
            distance_array.append(distance_x)

        sum_distance = np.sum(distance_array)
        distance_array = [distance / sum_distance for distance in distance_array]

        center_index = np.random.choice(len(points), 1, distance_array)

        centers.append(points[center_index[0]])

    return centers

def lloyds(centers, points):

    k=0

    while True:
        k = k+1

        clusters_dict, clusters_list = get_clusters(centers, points)

        new_centers = []

        for cluster in clusters_list:
            x = 0
            y = 0
            for point in cluster:
                x = x + point[0]
                y = y + point[1]
            x = x/len(cluster)
            y = y/len(cluster)

            center = (x, y)
            new_centers.append(center)

        difference = [c for c in new_centers if c not in centers]
        centers = new_centers
        if len(difference) == 0:
            break;

    #print(k);
    return centers;

def compare_clusters(k_clusters, clusters):

    # print(gonzalez_clusters)
    # print(clusters)
    # print()

    for k_cluster in k_clusters:
        match_found = False

        for cluster in clusters:
            if set(k_cluster) == set(cluster):
                match_found = True

        if match_found == False:
            return False
    return True


with open('C2.txt') as file:
    contents = file.read()
    contents = contents.split('\n')
    contents = [content for content in contents if content]

    points = []

    for content in contents:
        point = content.split('\t')[1:3]
        point = [float(coordinate) for coordinate in point]
        points.append(tuple(point))

#####################################

centers = []
centers.append(points[0])
centers.append(points[1])
centers.append(points[2])

centers = lloyds(centers, points)
print("Initial C : points indexed {1, 2, 3}")
print('\tFinal subset : ' + str(centers))

k_means_cost = get_cost(centers, points)
print('\t3-means cost : '+str(k_means_cost))

clusters_dict, clusters_list = get_clusters(centers, points)
plot_clusters(['r', 'blue', 'g'], clusters_dict, centers)
plt.title('Initial C : points indexed {1, 2, 3}')
plt.show()

#####################################

centers = [[-2.7694973, 2.6778586], [-2.0, 14.0], [-0.4032861, -5.4479696]]
centers = lloyds(centers, points)
print("\nInitial C : Gonzalez output")
print('\tFinal subset : ' + str(centers))

k_means_cost = get_cost(centers, points)
print('\t3-means cost : '+str(k_means_cost))

clusters_dict, clusters_list = get_clusters(centers, points)
plot_clusters(['r', 'blue', 'g'], clusters_dict, centers)
plt.title('Initial C : Gonzalez output')
plt.show()

#####################################
trial_count = 150
similar_count = 0
kmeans_cost_array = []

for i in range(trial_count):
    kmeans_centers = get_centers_kmeans(points, 3)
    centers = lloyds(kmeans_centers, points)

    # print('\nInitial C : k-means++ Trial ' + str(i))
    # print('\tFinal subset : ' + str(centers))

    k_means_cost = get_cost(centers, points)
    kmeans_cost_array.append(k_means_cost)
    # print('\t3-means cost : ' + str(k_means_cost))

    # clusters_dict, clusters_list = get_clusters(centers, points)
    # plot_clusters(['r', 'blue', 'g'], clusters_dict, centers)
    # plt.title('Initial C : k-means++ Trial ' + str(i))
    # plt.show()

    # difference = [c for c in kmeans_centers if c not in centers]
    # if len(difference) == 0:
    #     similar_count = similar_count + 1

    k_clusters, k_clusters_list = get_clusters(kmeans_centers, points)
    clusters_dict, clusters_list = get_clusters(centers, points)

    areClustersSame = compare_clusters(clusters_list, k_clusters_list );
    if areClustersSame == True:
        similar_count = similar_count + 1

print(np.sort(kmeans_cost_array))
x, y = ecdf(kmeans_cost_array)

plt.plot(x, y, marker='.')
plt.title('Initial Input : Kmeans++ output : ECDF')
plt.xlabel('3-means cost')
plt.ylabel('CDF')
plt.show()

print('\nInitial Input : kmeans++ output')
print("\tSame as Input : " + str(similar_count/trial_count))