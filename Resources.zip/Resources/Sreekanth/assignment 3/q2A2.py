# K-means ++

import sys
import math
import numpy as np
import matplotlib.pyplot as plt

def ecdf(data):
    """Compute ECDF for a one-dimensional array of measurements."""

    # Number of data points: n
    n = len(data)

    # x-data for the ECDF: x
    x = np.sort(data)

    # y-data for the ECDF: y
    y = np.arange(1, n+1) / n

    return x, y

def plot_clusters(colors, clusters, centers):
    cluster_list = []

    for key, value in clusters.items():
        cluster_list.append(value)

    for i in range(len(cluster_list)):
        cluster = cluster_list[i]

        x = []
        y = []

        for point in cluster:
            x.append(point[0])
            y.append(point[1])

        plt.plot(x, y, marker='.', linestyle='none', color=colors[i])

    # for center in centers:
    #     plt.plot(center[0], center[1], marker='.', linestyle='none', color='black')

def distance(c, x):
    sum = 0
    for i in range(len(c)):
        sum = sum + (c[i] - x[i]) ** 2
    return math.sqrt(sum)

def phi_c_x(centers, x):
    shortest_distance = sys.maxsize
    candidate_c = None

    for c in centers:
        distance_c_x = distance(c, x)
        if distance_c_x < shortest_distance:
            shortest_distance = distance_c_x
            candidate_c = c

    return candidate_c;


def get_centers_kmeans(points, k):
    centers = []

    center_1_index = np.random.randint(0, len(points))
    centers.append(points[0])

    # print(centers)

    for i in range(1, k):

        distance_array = []

        for point in points:
            distance_x = distance(point, phi_c_x(centers, point))
            distance_array.append(distance_x)

        sum_distance = np.sum(distance_array)
        distance_array = [distance / sum_distance for distance in distance_array]

        center_index = np.random.choice(len(points), 1, distance_array)

        centers.append(points[center_index[0]])

    return centers

def get_clusters(centers, points):

    clusters = {}

    for point in points:
        center_x = phi_c_x(centers, point)
        key = str(center_x[0]) + str(center_x[1])

        if key in clusters.keys():
            clusters[key].append(point)
        else:
            clusters[key] = [point]

    return clusters;

def get_cost(centers, points):
    k_center_cost = 0
    sum = 0

    for point in points:
        center_x = phi_c_x(centers, point)
        distance_x = distance(point, center_x)
        k_center_cost = max(k_center_cost, distance_x)

        sum = sum + distance_x ** 2

    k_means_cost = math.sqrt(sum / len(points))

    return k_center_cost, k_means_cost

def compare_clusters(gonzalez_clusters, clusters):

    # print(gonzalez_clusters)
    # print(clusters)
    # print()

    g_clusters_list = []
    for key, value in gonzalez_clusters.items():
        g_clusters_list.append(value)

    clusters_list = []
    for key, value in clusters.items():
        clusters_list.append(value)


    for g_cluster in g_clusters_list:
        match_found = False

        for cluster in clusters_list:
            if set(g_cluster) == set(cluster):
                match_found = True

        if match_found == False:
            return False

    return True

with open('C2.txt') as file:
    contents = file.read()
    contents = contents.split('\n')
    contents = [content for content in contents if content]

    points = []

    for content in contents:
        point = content.split('\t')[1:3]
        point = [float(coordinate) for coordinate in point]
        points.append(tuple(point))

trial_count = 30

gonzalez_centers = [[-2.7694973, 2.6778586], [-2.0, 14.0], [-0.4032861, -5.4479696]]
gonzalez_clusters = get_clusters(gonzalez_centers, points)
similar_count = 0

k_means_cost_array = []

for i in range(trial_count):
    centers = get_centers_kmeans(points, 3)
    #print("Centers : " + str(centers))

    clusters = get_clusters(centers, points)
    k_center_cost, k_means_cost = get_cost(centers, points)

    k_means_cost_array.append(k_means_cost)

    # difference = [c for c in gonzalez_centers if c not in centers]
    # if len(difference) == 0:
    #     similar_count = similar_count + 1

    areClustersSame = compare_clusters(gonzalez_clusters, clusters);
    if areClustersSame == True:
        similar_count = similar_count + 1

    #print("\n3-center cost : " + str(k_center_cost))
    #print("\n3-means cost : " + str(k_means_cost))

    # plot_clusters(['r', 'blue', 'g'], clusters, centers)
    # plt.show()

x, y = ecdf(k_means_cost_array)

plt.plot(x, y, marker='.')
plt.xlabel('3-means cost')
plt.ylabel('CDF')
plt.show()

print("Same as Gonzalez : " + str(similar_count/trial_count))