import sys
import numpy as np
import math

# def distance(c, x):
#     sum = 0
#     for coordinate in range(len(c)):
#         sum = sum + abs(c[coordinate] - x[coordinate])
#     return sum

def distance(c, x):
    sum = 0
    for i in range(len(c)):
        sum = sum + (c[i] - x[i]) ** 2

    return math.sqrt(sum)

def phi_c_x(centers, x):
    shortest_distance = sys.maxsize
    candidate_c = None

    for c in centers:
        distance_c_x = distance(c, x)
        if distance_c_x < shortest_distance:
            shortest_distance = distance_c_x
            candidate_c = c

    return candidate_c;

def get_clusters(centers, points):

    clusters_dict = {}

    for point in points:
        center_x = phi_c_x(centers, point)
        key = str(center_x[0]) + str(center_x[1])

        if key in clusters_dict.keys():
            clusters_dict[key].append(point)
        else:
            clusters_dict[key] = [point]

    clusters_list = []
    for key, value in clusters_dict.items():
        clusters_list.append(value)

    return clusters_dict, clusters_list;

def get_centers_for_lloyds(points, k):
    centers = []

    center_1_index = np.random.randint(0, len(points))
    centers.append(points[center_1_index])

    for i in range(1, k):

        distance_array = []

        for point in points:
            distance_x = distance(point, phi_c_x(centers, point)) ** 2
            distance_array.append(distance_x)

        sum_distance = np.sum(distance_array)
        distance_array = [distance / sum_distance for distance in distance_array]

        center_index = np.random.choice(len(points), 1, distance_array)

        centers.append(points[center_index[0]])

    return centers

def lloyds(centers, points):

    k=0

    while True:
        k = k+1

        clusters_dict, clusters_list = get_clusters(centers, points)
        new_centers = []

        for cluster in clusters_list:
            x1 = []
            x2 = []
            x3 = []
            x4 = []
            x5 = []
            for point in cluster:
                x1.append(point[0])
                x2.append(point[1])
                x3.append(point[2])
                x4.append(point[3])
                x5.append(point[4])

            center = []
            center.append(np.median(x1))
            center.append(np.median(x2))
            center.append(np.median(x3))
            center.append(np.median(x4))
            center.append(np.median(x5))

            new_centers.append(tuple(center))

        difference = [c for c in new_centers if c not in centers]
        centers = new_centers
        if len(difference) == 0:
            break;

    return centers;

def get_cost(centers, points):

    cost = 0
    for point in points:
        center_x = phi_c_x(centers, point)
        distance_x = distance(point, center_x)
        cost = cost + distance_x
    return cost/len(points)

with open('C3.txt') as file:
    contents = file.read()
    contents = contents.split('\n')
    contents = [content for content in contents if content]

    points = []
    for content in contents:
        point = content.split('\t')[1:6]
        point = [float(coordinate) for coordinate in point]
        points.append(point)

print('k-medians clustering with k=4\n')

centers = get_centers_for_lloyds(points, 4)
centers = lloyds(centers, points)
print('k-medians cost : ' + str(get_cost(centers, points)))

print('\nCenters : ')
for center in centers:
    print('\t' + str(center))

# Writing centers to a file
with open('../4-medians.txt', 'w') as file:
    for i in range(1, len(centers)+1):
        file.write(str(i) + '\t' + str(centers[i-1][0]) + '\t' + str(centers[i-1][1]) + '\t' + str(centers[i-1][2]) + '\t' + str(centers[i-1][3]) + '\t' + str(centers[i-1][4]) + '\n')
    file.close()


print('\n#################################\n')

print('k-medians clustering with k=5\n')

centers = get_centers_for_lloyds(points, 5)
centers = lloyds(centers, points)
print('k-medians cost : ' + str(get_cost(centers, points)))

print('\nCenters : ')
for center in centers:
    print('\t' + str(center))