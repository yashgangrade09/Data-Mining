import random
import numpy as np
import matplotlib.pyplot as plt
import time

def countTrials(n):
    k = 0
    generatedNumbers = set()
    while (True):
        k = k + 1
        i = random.randint(1, n)
        if len(generatedNumbers)==n:
            break
        generatedNumbers.add(i)
    return k
print("number of trails", countTrials(250))
trials = []
for i in range(0, 300):
    trials.append(countTrials(250))

x = np.sort(trials)
# print(x)
y = np.arange(1, len(x)+1)/len(x)
_ = plt.plot(x, y, marker='.', linestyle = 'none')
_ = plt.xlabel('number of trials')
_ = plt.ylabel('fraction of experiments')
plt.margins(0.02)
plt.show()