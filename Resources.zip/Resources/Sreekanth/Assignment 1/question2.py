import random
import numpy as np
import matplotlib.pyplot as plt
import time

def countTrials(n):
    k = 0
    generatedNumbers = set()
    while (True):
        k = k + 1
        i = random.randint(1, n)
        if len(generatedNumbers)==n:
            break
        generatedNumbers.add(i)
    return k
# 2.a answer
print("q2.a ",countTrials(250))

#2.b answer

trials = []
start = time.time()
for i in range(0, 300):
    trials.append(countTrials(4000))
end = time.time()

x = np.sort(trials)
# print(x)
y = np.arange(1, len(x)+1)/len(x)
_ = plt.plot(x, y, marker='.', linestyle = 'none')
_ = plt.xlabel('number of trials (n)')
_ = plt.ylabel('fraction of experiments')
plt.margins(0.02)
plt.show()

#2.c answer
totalTrials = sum(trials)
print("q2.c expected k, ", totalTrials/300)

#2.d answer
print("q2.d time for 300 trials ", end-start)

m_values = [300, 2500, 5000]
n_values = [5000, 10000, 15000, 20000]
for i in m_values:
    times = []
    list_trials = []
    for j in n_values:
        started = time.time()
        for s in range(0, i):
            list_trials.append(countTrials(j))
        ended = time.time()
        times.append(ended - started)
    plt.plot(n_values, times)
plt.xlabel("number of trials (n)")
plt.ylabel("run time in seconds")
plt.legend(['m = 300', 'm = 2500', 'm = 5000'])
plt.show()