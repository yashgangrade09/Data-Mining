import random
import numpy as np
import matplotlib.pyplot as plt
import time

def countTrials(n):
    k = 0
    generatedNumbers = set()
    while (True):
        k = k + 1
        i = random.randint(1, n)
        if len(generatedNumbers)==n:
            break
        generatedNumbers.add(i)
    return k

m_values = [300, 2500, 5000]
n_values = [5000, 10000, 15000, 20000]
for i in m_values:
    times = []
    list_trials = []
    for j in n_values:
        started = time.time()
        for s in range(0, i):
            list_trials.append(countTrials(j))
        ended = time.time()
        times.append(ended - started)
    plt.plot(n_values, times)
plt.show()