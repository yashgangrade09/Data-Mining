import random
import numpy as np
import matplotlib.pyplot as plt
import time

def countTrials(n):
    k = 0
    generatedNumbers = set()
    while (True):
        k = k + 1
        i = random.randint(1, n)
        if len(generatedNumbers)==n:
            break
        generatedNumbers.add(i)
    return k
print("number of trails", countTrials(250))