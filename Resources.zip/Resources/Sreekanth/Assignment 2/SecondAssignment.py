'''
Created on Feb 8, 2017

@author: admin
'''
import nltk
from nltk.util import ngrams
from collections import Counter
import binascii
import random
import time
import matplotlib.pyplot as plt
import math

def generate_wordgrams(file_name):
    with open(file_name) as f: 
        data = f.readline()
      
    token = nltk.word_tokenize(str(data))
    bigrams = ngrams(token,2)      
    bicharacters= set()
    tricharacters=set()
    data = str(data)
    for i in range(len(data)-1):
        bicharacters.add(data[i:i+2])
    for i in range(len(data)-2):
        tricharacters.add(data[i:i+3])
    # print(bicharacters)
    # print(tricharacters)
    return bigrams, bicharacters, tricharacters 

def jaccard_similarity(file_name1, file_name2):
    bigrams1, bicharacters1, tricharacters1 = generate_wordgrams(file_name1)
    bigrams2, bicharacters2, tricharacters2= generate_wordgrams(file_name2)
    #print(Counter(bigrams1))
    #print(Counter(bigrams2))
    a = Counter(bigrams1) 
    b = Counter(bigrams2)
    c = Counter(bicharacters1) 
    d = Counter(bicharacters2)
    e = Counter(tricharacters1) 
    f = Counter(tricharacters2)     
    print(len(c+d))
    print(len(c&d))
    print(len(c&d)/len(c+d))
    print(len(e+f))
    print(len(e&f))
    print(len(e&f)/len(e+f))
    print(len(a+b))
    print(len(a&b))
    print(len(a&b)/len(a+b))
    
def pickRandomCoeffs(k):
  randList = []  
  while k > 0:    
    randIndex = random.randint(0, 2**32-1)    
    while randIndex in randList:
      randIndex = random.randint(0, 2**32-1)    
    randList.append(randIndex)
    k = k - 1   
  return randList   

def min_hashing(file_name1, file_name2, hashes):
    bigrams1, bicharacters1, tricharacters1 = generate_wordgrams(file_name1)
    bigrams2, bicharacters2, tricharacters2= generate_wordgrams(file_name2)
    shinglesInDoc1 = set()
    shinglesInDoc2 = set()
    nextPrime = 4294967311
    for elem in tricharacters1:
        shingle =elem
        crc = binascii.crc32(shingle.encode()) & 0xffffffff
        shinglesInDoc1.add(crc)
    for elem in tricharacters2:
        shingle = elem
        crc = binascii.crc32(shingle.encode()) & 0xffffffff
        shinglesInDoc2.add(crc)   
    coeffA = pickRandomCoeffs(hashes)
    coeffB = pickRandomCoeffs(hashes)
    signature1= []
    signature2= []
    for i in range(0, hashes):
        minHashCode = nextPrime + 1
        for shingleID in shinglesInDoc1:
             hashCode = (coeffA[i] * shingleID + coeffB[i]) % nextPrime
             if hashCode < minHashCode:
                 minHashCode = hashCode
        signature1.append(minHashCode)  
    for i in range(0, hashes):
        minHashCode = nextPrime + 1
        for shingleID in shinglesInDoc2:
             hashCode = (coeffA[i] * shingleID + coeffB[i]) % nextPrime
             if hashCode < minHashCode:
                 minHashCode = hashCode
        signature2.append(minHashCode)
    count =0
    for i in range(0, len(signature1)):
        if signature1[i] == signature2[i]:
           count = count+1;
    print(count/hashes)
    return count/hashes       
        
           

     
#bigrams, bicharacters, tricharacters = generate_wordgrams('yelp_dataset_challenge_round9')
#print(len(Counter(bigrams)))
#print(len(bicharacters))
#print(len(tricharacters))
jaccard_similarity('D1.txt', 'D2.txt')
#20
exp =[None]*5
start_time = time.time()
t = {20, 60, 150, 300, 600}
for item in t:
  print(min_hashing('D1.txt', 'D2.txt', item))

# print('Time is', time.time()-start_time)
# print('avg is', exp)
# data = [0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1.0]
# y = [None]*10
# for i in range(0,len(data)):
#     y[i] = math.pow(data[i],6)
#     y[i] = 1-y[i]
#     y[i] =  math.pow(y[i],26)
#     y[i] = 1-y[i]
# plt.plot(data,y)
# plt.title('b =6 and r =26')
#plt.show()     
    
    
    
        
        