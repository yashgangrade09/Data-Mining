import random
import binascii
from collections import Counter
import matplotlib.pyplot as plt

import math
import nltk
import time
from nltk.util import ngrams

def readFile(name):
    file = open(name)
    text = file.read()
    return text
def characterTokenize(text, k):
    bicharacters = set()
    for i in range(len(text)-k+1):
        bicharacters.add(text[i:i+k])
    return bicharacters

def wordTokenize(text, k):
    words = text.split(" ")
    wordSplit = [words[i:i+k] for i in range(len(words)-k+1)]
    return set(tuple(row) for row in wordSplit)

d1 = readFile("D1.txt")
d2 = readFile("D2.txt")
d3 = readFile("D3.txt")
d4 = readFile("D4.txt")

# for k = 2 characters
d12 = characterTokenize(d1, 2)
d22 = characterTokenize(d2, 2)
d32 = characterTokenize(d3, 2)
d42 = characterTokenize(d4, 2)
print("d12: "+str(len(d12)))
print("d22: "+str(len(d22)))
print("d32: "+str(len(d32)))
print("d42: "+str(len(d42)))
print("---------------------------------------------------------")
# for k = 3 characters
d13 = characterTokenize(d1, 3)
d23 = characterTokenize(d2, 3)
d33 = characterTokenize(d3, 3)
d43 = characterTokenize(d4, 3)
print("d13: "+str(len(d13)))
print("d23: "+str(len(d23)))
print("d33: "+str(len(d33)))
print("d43: "+str(len(d43)))
print("---------------------------------------------------------")
# for k=2 words
d1words = wordTokenize(d1, 2)
d2words = wordTokenize(d2, 2)
d3words = wordTokenize(d3, 2)
d4words = wordTokenize(d4, 2)

print("d1 words: "+str(len(d1words)))
print("d2 words: "+str(len(d2words)))
print("d3 words: "+str(len(d3words)))
print("d4 words: "+str(len(d4words)))
print("---------------------------------------------------------")
# jaccard similarity

def calculateJaccard(set1, set2):
    a = Counter(set1)
    b = Counter(set2)
    return len(a&b)/len(a+b)

#Jaccard similarities calculations for k = 2 character
print("d12-d22: "+str(calculateJaccard(d12, d22)))
print("d12-d32: "+str(calculateJaccard(d12, d32)))
print("d12-d42: "+str(calculateJaccard(d12, d42)))
print("d22-d32: "+str(calculateJaccard(d22, d32)))
print("d22-d42: "+str(calculateJaccard(d22, d42)))
print("d32-d42: "+str(calculateJaccard(d32, d42)))
print("---------------------------------------------------------")
#Jaccard similarities calculations for k = 3 character
print("d13-d23: "+str(calculateJaccard(d13, d23)))
print("d13-d33: "+str(calculateJaccard(d13, d33)))
print("d13-d43: "+str(calculateJaccard(d13, d43)))
print("d23-d33: "+str(calculateJaccard(d23, d33)))
print("d23-d43: "+str(calculateJaccard(d23, d43)))
print("d33-d43: "+str(calculateJaccard(d33, d43)))
print("---------------------------------------------------------")
#Jaccard similarities calculations for k = 2 words
print("d1words-d2words: "+str(calculateJaccard(d1words, d2words)))
print("d1words-d3words: "+str(calculateJaccard(d1words, d3words)))
print("d1words-d4words: "+str(calculateJaccard(d1words, d4words)))
print("d2words-d3words: "+str(calculateJaccard(d2words, d3words)))
print("d2words-d4words: "+str(calculateJaccard(d2words, d4words)))
print("d3words-d4words: "+str(calculateJaccard(d3words, d4words)))

# question 2
def pickRandomCoeffs(k):
  randList = []
  while k > 0:
    randIndex = random.randint(0, 2**32-1)
    while randIndex in randList:
      randIndex = random.randint(0, 2**32-1)
    randList.append(randIndex)
    k = k - 1
  return randList

def min_hashing(set1, set2, hashes):
    shinglesInDoc1 = set()
    shinglesInDoc2 = set()
    nextPrime = 4294967311
    for elem in set1:
        shingle =elem
        crc = binascii.crc32(shingle.encode()) & 0xffffffff
        shinglesInDoc1.add(crc)
    for elem in set2:
        shingle = elem
        crc = binascii.crc32(shingle.encode()) & 0xffffffff
        shinglesInDoc2.add(crc)
    coeffA = pickRandomCoeffs(hashes)
    coeffB = pickRandomCoeffs(hashes)
    signature1= []
    signature2= []
    for i in range(0, hashes):
        minHashCode = nextPrime + 1
        for shingleID in shinglesInDoc1:
             hashCode = (coeffA[i] * shingleID + coeffB[i]) % nextPrime
             if hashCode < minHashCode:
                 minHashCode = hashCode
        signature1.append(minHashCode)
    for i in range(0, hashes):
        minHashCode = nextPrime + 1
        for shingleID in shinglesInDoc2:
             hashCode = (coeffA[i] * shingleID + coeffB[i]) % nextPrime
             if hashCode < minHashCode:
                 minHashCode = hashCode
        signature2.append(minHashCode)
    count =0
    for i in range(0, len(signature1)):
        if signature1[i] == signature2[i]:
           count = count+1;
    return count/hashes

#question 2.A
print("-------------------------------------------")
t = {20, 60, 150, 300, 600}
for item in t:
    print("for t = "+str(item)+": "+str(min_hashing(d13, d23, item)))

#Question 2.B
print("for 10 iterations ------------------------")
for item in t:
    start = time.time()
    for i in range(0,10):
        print("for t = " + str(item) + ": " + str(min_hashing(d13, d23, item)))
    end = time.time()
    print("time for t = " + str(item) + ": " + str(end-start))
print("for 10 iterations ------------------------")

# data = [0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1.0]
# y = [None]*10
# for i in range(0,len(data)):
#     y[i] = math.pow(data[i],10)
#     y[i] = 1-y[i]
#     y[i] =  math.pow(y[i],16)
#     y[i] = 1-y[i]
# plt.plot(data,y)
# plt.title('b =10 and r =16')
# plt.show()