#!/usr/bin/env python3
#Spencer Fronberg
#CS 6635
from scipy.cluster.hierarchy import dendrogram, linkage
import numpy as np
import math
import matplotlib.pyplot as plt
import sys
from collections import defaultdict
import itertools
import statistics
import random as r
r.seed(0)

def Get_Doc(doc):
    file = open(doc, "r")
    d = []
    for line in file:
        l = line.split("\t")
        t = []
        for i in l[1:]:
            t.append(float(i))
        d.append(t)
    return d
def Clusters(C1, type, title):
    plt.figure(figsize=(25, 10))
    plt.title(title)
    plt.xlabel("clusters")
    plt.ylabel("Distance")
    dendrogram(linkage(C1, type), leaf_rotation=90, leaf_font_size=10, show_leaf_counts=True)
    plt.show()
    return

def Part1():
    C1 = Get_Doc("C1.txt")
    #C2 = Get_Doc("C2.txt")
    #C3 = Get_Doc("C3.txt")
    Clusters(C1, "single", "Single-Link Cluster")
    Clusters(C1, "complete", "Complete-Link Cluster")
    Clusters(C1, "centroid", "Mean-Link Cluster")
    x = []
    y = []
    for i in C1:
        x.append(i[0])
        y.append(i[1])
    plt.scatter(x, y)
    plt.show()
    #print(C1)
    return

def Get_Distance(centroid, point):
    total = 0
    for i in range(len(centroid)):
        total = total + math.pow(centroid[i] - point[i], 2)
    return math.sqrt(total)

def Plot(clusters, title):
    colors = itertools.cycle(["r", "b", "g"])
    p = 1
    for key, value in clusters.items():
        x = []
        y = []
        for i in value:
            x.append(i[0])
            y.append(i[1])
        plt.scatter(x, y, color=next(colors))
        #print("Cluster " + str(p) + ":\t", end="")
        #print(value)
        p += 1
    plt.title(title)
    plt.show()
    return

def Gonzalez(C2, k, lloyds):
    centroids = []
    centroids.append(C2[0])
    for i in range(1, k+1):
        clusters = defaultdict(list)
        dist = [0, []]
        for i in C2:
            c = [sys.maxsize, []]
            for j in centroids:
                d = Get_Distance(j, i)
                if(d < c[0]):
                    c = [d, j]
            clusters[str(c[1])].append(i)
            d2 = Get_Distance(c[1], i)
            if(d2 > dist[0]):
                dist = [d2, i]
        centroids.append(dist[1])
    if (not lloyds):
        print(centroids)
        print("Total Cost: " + str(dist[0]))
        Plot(clusters, "Gonzalez")
    return centroids

def Cumulative_Plot(costs):
    #print(costs)
    x = np.sort(costs)
    y = np.arange(1, len(x)+1) / len(x)
    plt.plot(x, y, marker='.', linestyle='none')
    plt.xlabel('Costs')
    plt.show()
    return

def k_means(C2, k, recall, costs, lloyds):
    centroids = []
    centroids.append(C2[0])
    for p in range(1, k + 1):
        clusters = defaultdict(list)
        dist = [0, []]
        distances = []
        for i in C2:
            c = [sys.maxsize, []]
            for j in centroids:
                d = Get_Distance(j, i)
                if (d < c[0]):
                    c = [d, j]
            clusters[str(c[1])].append(i)
            d2 = Get_Distance(c[1], i)**2
            distances.append([d2, i])
        l = list(i[0] for i in distances)
        total = sum(l)
        distances2 = distances
        distances = list([i[0] / total, i[1]] for i in distances)
        number = np.random.rand()
        range1 = 0
        for i in distances:
            if(range1 < number <= range1 + i[0] and len(centroids) < k):
                centroids.append(i[1])
            range1 += i[0]
        cost = math.sqrt(sum(i[0] for i in distances2) / len(distances2))
    #print(centroids)
    #print("The cost is: " + str(cost))
    #Plot(clusters)
    if(lloyds):
        return centroids
    elif(recall != 0):
        costs.append(cost)
        return k_means(C2, k, recall - 1, costs, lloyds)
    else:
        Plot(clusters, "K-MEANSSSS")
        Cumulative_Plot(costs)
        return

def Part2A():
    C2 = Get_Doc("C2.txt")
    print("Part 2A (Gonzalez)")
    Gonzalez(C2, 3, False)
    print("Part 2A (k-means)")
    costs = []
    k_means(C2, 3, 20, costs, False)
    return

def Get_Clusters(C2, centers):
    clusters = defaultdict(list)
    for i in C2:
        c = [sys.maxsize, []]
        for j in centers:
            d = Get_Distance(j, i)
            if (d < c[0]):
                c = [d, j]
        clusters[str(c[1])].append(i)
    return clusters

def Lloyds(C2, centers, title, kmeans):
    for z in range(10):
        clusters = Get_Clusters(C2, centers)
        new_centers = []
        for key, cluster in clusters.items():
             center = [0] * len(cluster[0])
             for i in cluster:
                 for j in range(len(cluster[0])):
                    center[j] = center[j] + i[j]
             center = list(i / len(cluster) for i in center)
             new_centers.append(center)
        centers = new_centers

    if(not kmeans):
        print("The new centers are: ")
        print(new_centers)
    new_clusters = Get_Clusters(C2, new_centers)
    if(not kmeans):
        Plot(new_clusters, title)

    dist = [0, []]
    distances = []
    for i in C2:
        c = [sys.maxsize, []]
        for j in new_centers:
            d = Get_Distance(j, i)
            if (d < c[0]):
                c = [d, j] # this is the [distance to its center, its center] for each point
        d2 = Get_Distance(c[1], i) ** 2
        distances.append([d2, i])
    cost = math.sqrt(sum(i[0] for i in distances) / len(distances))
    if(not kmeans):
        print("The total cost for " + title + " is: ")
        print(cost)
        return
    else:
        equal = True
        #for i in range(len(new_clusters)):
        for old_cluster, new_cluster in zip(clusters.values(), new_clusters.values()):
            for old_point, new_point in zip(old_cluster, new_cluster):
                for j in range(len(old_point)):
                    if old_point[j] != new_point[j]:
                        equal = False
        return cost, equal

def Part2B():
    C2 = Get_Doc("C2.txt")
    print("Part 2B (Lloyds)\n")
    print("C initially with points indexed {1, 2, 3}")
    Lloyds(C2, C2[:3], "Points Indexed at {1, 2, 3}", False)
    print("\nC initially as output of Gonzalez: ")
    Lloyds(C2, Gonzalez(C2, 3, True)[:3], "Points Indexed at Gonzalez", False)
    #print("\nC initially as output of k-means: ")
    costs = []
    cost = []
    j = 0
    for i in range(20):
        c, equal = Lloyds(C2, k_means(C2, 3, 0, cost, True), "Points Indexed at k-means", True)
        costs.append(c)
        if equal:
            j = j + 1
    print("A total of " + str(j / 20 * 100) + "% of the subsets are the same as the input")
    Cumulative_Plot(costs)
    return

def Expantion_Factor(d):
    return (2 * math.factorial(d / 2)**(1/d)) / math.sqrt(math.pi)
def Part3_5():
    Expantion_Facotrs = []
    Ds = []
    for i in range(1, 11):
        Expantion_Facotrs.append(Expantion_Factor(i*2))
        Ds.append(int(i*2))
    plt.scatter(Ds, Expantion_Facotrs)
    plt.xticks(list(i if i % 2 == 0 else 0 for i in range(21)))
    plt.title("Even Expansion Factors")
    plt.show()
    return

def Write_To_File(centers):
    file = open("centers-" + str(len(centers)) + "-Median.txt", "w")
    st = ""
    i = 1
    for point in centers:
        st = st + str(i) + "\t"
        for coor in point:
            st = st + str(coor) + "\t"
        st = st + "\n"
        i += 1
    file.write(st)
    file.close()
    return

def k_median(C3, centers, title):
    for z in range(10):
        clusters = Get_Clusters(C3, centers)
        new_centers = []
        for key, cluster in clusters.items():
             center = []
             for j in range(len(cluster[0])):
                  center.append(np.median(list(i[j] for i in cluster)))
             new_centers.append(center)
        centers = new_centers

    print("The new centers are: ")
    print(new_centers)
    Write_To_File(new_centers)

    new_clusters = Get_Clusters(C3, new_centers)

    dist = [0, []]
    distances = []
    for i in C3:
        c = [sys.maxsize, []]
        for j in new_centers:
            d = Get_Distance(j, i)
            if (d < c[0]):
                c = [d, j] # this is the [distance to its center, its center] for each point
        d2 = Get_Distance(c[1], i)
        distances.append([d2, i])
    cost = sum(i[0] for i in distances) / len(distances)
    print("The total cost for " + title + " is: ")
    print(cost)
    return

def Part4():
    C3 = Get_Doc("C3.txt")
    costs = []
    k_median(C3, k_means(C3, 4, 0, costs, True), "4-median")
    k_median(C3, k_means(C3, 5, 0, costs, True), "5-median")
    #k_median(C3, C3[:4], "4-median")
    #k_median(C3, C3[:5], "5-median")
    return

def main():
    Part1()
    Part2A()
    Part2B()
    Part3_5()
    Part4()
    return

if __name__ == "__main__":
    main()
    exit(0)