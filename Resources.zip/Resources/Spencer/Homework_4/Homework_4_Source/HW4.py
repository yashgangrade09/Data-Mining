#!/usr/bin/env python3
#Spencer Fronberg
#CS 6140
import math
import sys
import os
os.environ['PYTHONHASHSEED'] = '123'

def Get_Doc(doc):
    file = open(doc, "r")
    for line in file:
        return str(line)

def Misra_Gries(streams, k, m, percent):
    counters = [0] * (k-1)
    common = [""] * (k-1)

    for letter in streams:
        if (letter in common):
            index = common.index(letter)
            counters[index] = counters[index] + 1
        else:
            if 0 in counters:
                index = counters.index(0)
                common[index] = letter
                counters[index] = counters[index] + 1
            else:
                for i in range(len(counters)):
                    counters[i] = counters[i] - 1
    print(common, end="")
    print(" \\\\")
    print(counters, end="")
    print(" \\\\")
    #Might occur more than 20%
    C = m / k
    i = 0
    for count in counters:
        if((count + C) / m * 100 >= percent):
            i = i + 1
    print("How many objects might occur more than " + str(percent) + "\\% of the time?\t" + str(i) + " \\\\")
    #Must occur more than 20%
    i = 0
    for count in counters:
        if (count / m * 100 >= percent):
            i = i + 1
    print("How many objects must occur more than " + str(percent) + "\\% of the time?\t" + str(i) + " \\\\ \\\\")
    return

def Part1A():
    S1 = Get_Doc("S1.txt")
    print("Part 1A \\\\ \\\\ \n")
    print("For S1: \\\\")
    Misra_Gries(S1, 10, len(S1), 20)
    S2 = Get_Doc("S2.txt")
    print("\nFor S2: \\\\")
    Misra_Gries(S2, 10, len(S2), 20)
    #print(len(S1))
    #print(len(S2))
    return

def Count_Min(doc, t, k):
    matrix = []
    for i in range(t):
        l = [0] * k
        for j in doc:
            hsh = hash(j+str(i)) % k
            #print(j + " is " + str(hsh))
            l[hsh] += 1
        matrix.append(l)
    return matrix

def Parse(matrix, k, m):
    c = []
    for j in ["a", "b", "c"]:
        i = 0
        counts = []
        for row in matrix:
            hsh = hash(j + str(i)) % k
            counts.append(row[hsh])
            i += 1
        count = min(counts)
        print(j + " is " + str(count))
        c.append(count)
    p = 0
    for i in c:
        if i / m * 100 >= 20:
            p += 1
    print("The number of 20% is:\t" + str(p))
    return

def Part1B():
    print("\nFor S1: \\\\")
    matrix = Count_Min(Get_Doc("S1.txt"), 5, 10)
    Parse(matrix, 10, 1000000)
    print("\nFor S2: \\\\")
    matrix2 = Count_Min(Get_Doc("S2.txt"), 5, 10)
    Parse(matrix2, 10, 1000000)
    return

if __name__ == "__main__":
    Part1A()
    Part1B()
    exit(0)