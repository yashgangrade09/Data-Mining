# !/usr/bin/env python3
# -*- coding:utf-8 -*-
#
# Author: Flyaway - flyaway1217@gmail.com
# Blog: zhouyichu.com
#
# Python release: 3.4.5
#
# Date: 2017-03-14 10:34:37
# Last modified: 2017-03-14 10:57:07

"""
Simple implementation of min-count sketch algorithm
"""

import random


def generate_hashing(a, b, k=10):
    def hashing(string):
        x = hash(string)
        return ((a*x)+b) % k
    return hashing


class Count_Min:
    def __init__(self, k, t):
        self._k = k
        self._t = t

        a = 1
        b = t * 10
        randint = random.randint

        self._hash_funcs = [generate_hashing(randint(a, b), randint(a, b))
                            for _ in range(t)]

    def count_min_sketch(self, stream):
        C = [0] * self._t
        for i in range(len(C)):
            C[i] = [0] * self._k

        for item in stream:
            for j, f in enumerate(self._hash_funcs):
                C[j][f(item)] += 1
        self._C = C

    def query(self, item):
        C = self._C
        values = [C[j][f(item)] for j, f in enumerate(self._hash_funcs)]
        return min(values)


def read(path):
    with open(path, encoding='utf8') as f:
        for line in f:
            for item in line:
                yield item


def real_count(path):
    counter = dict()
    for item in read(path):
        counter[item] = counter.get(item, 0) + 1
    return counter


if __name__ == '__main__':
    path = './data/S2.txt'
    counter = Count_Min(k=10, t=5)
    counter.count_min_sketch(read(path))
    print(counter.query('a'))
    print(counter.query('b'))
    print(counter.query('c'))

    print('-'*50)
    x = real_count(path)
    print(x['a'])
    print(x['b'])
    print(x['c'])
