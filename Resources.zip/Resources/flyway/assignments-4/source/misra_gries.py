# !/usr/bin/env python3
# -*- coding:utf-8 -*-
#
# Author: Flyaway - flyaway1217@gmail.com
# Blog: zhouyichu.com
#
# Python release: 3.4.5
#
# Date: 2017-03-09 13:05:43
# Last modified: 2017-03-09 13:34:17

"""
Implementation of Misra-Gries Algorithm.
"""


def misra(stream, k):
    """
    Args:
        stream: iter
        k: int
    """
    C = [0] * k
    L = [None] * k
    for item in stream:
        if item in L:
            j = L.index(item)
            C[j] += 1
        else:
            if 0 in C:
                j = C.index(0)
                L[j] = item
                C[j] = 1
            else:
                C = [v-1 for v in C]
    return C, L


def read(path):
    with open(path, encoding='utf8') as f:
        for line in f:
            for item in line:
                yield item

if __name__ == '__main__':
    path = './data/S2.txt'
    C, L = misra(read(path), 9)
    for counter, label in zip(C, L):
        s = ' '.join([label, str(counter)])
        print(s)
