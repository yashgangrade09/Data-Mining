import random


def hashing(a, m=10000):
    def hashing(string):
        x = hash(string)
        x = x % 1000
        print(int((x*a - int(x*a))*m))
    return hashing


h = hashing(random.random()*100)
h('abc')
