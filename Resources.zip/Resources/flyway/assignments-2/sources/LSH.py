# !/usr/bin/env python3
# -*- coding:utf-8 -*-
#
# Author: Flyaway - flyaway1217@gmail.com
# Blog: zhouyichu.com
#
# Python release: 3.4.5
#
# Date: 2017-02-11 11:14:51
# Last modified: 2017-02-11 11:37:29

"""
Plot the LSH.
"""

import matplotlib.pyplot as plt


def LSH(b=5, r=32):
    def func(s):
        x = s**b
        x = (1-x)**r
        return 1-x
    return func

def plot():
    x = [i / 20 for i in range(20)]
    func = LSH()
    y = [func(i) for i in x]
    plt.plot(x, y)
    plt.ylabel('Prob of checking d(D1, D2)', fontsize=30)
    plt.xlabel('s=JS(D1, D2)', fontsize=30)
    plt.show()


if __name__ == '__main__':
    # plot()
    func = LSH()
    print(func(0.362))

