# !/usr/bin/env python3
# -*- coding:utf-8 -*-
#
# Author: Flyaway - flyaway1217@gmail.com
# Blog: zhouyichu.com
#
# Python release: 3.4.5
#
# Date: 2017-02-10 11:05:07
# Last modified: 2017-02-12 20:44:24

"""
Creating k-Grams.

1. Construct 2-grams based on charachters,  for all documents.
2. Construct 3-grams based on charachters,  for all documents.
3. Construct 2-grams based on words, for all documents.
"""

import collections


def read(path, mode='character'):
    with open(path, encoding='utf8') as f:
        for line in f:
            if mode == 'character':
                for s in line:
                    if '\n' not in s:
                        yield s
            else:
                words = line.split()
                for w in words:
                    yield w


def k_gram(k, path, mode='character'):
    buf = collections.deque(maxlen=k)

    generator = read(path, mode)
    kgrams = set()
    while len(buf) != k:
        try:
            buf.append(next(generator))
        except StopIteration:
            raise Exception('Corpus length is less than k !')

    s = '-'.join(buf)
    kgrams.add(s)
    while len(buf) == k:
        try:
            buf.append(next(generator))
            s = '-'.join(buf)
            kgrams.add(s)
        except StopIteration:
            break
    # print(kgrams)
    return kgrams


def runA():
    paths = ['./data/D1.txt',
             './data/D2.txt',
             './data/D3.txt',
             './data/D4.txt']

    for path in paths:
        string = path

        # 2-grams based on characters
        n = k_gram(2, path, 'character')
        n = len(n)
        s1 = string + (' ' + 'G1:' + str(n))
        print(s1)

        # 3-grams based on characters
        n = k_gram(3, path, 'character')
        n = len(n)
        s2 = string + (' ' + 'G2:' + str(n))
        print(s2)

        # 2-grams based on words
        n = k_gram(2, path, 'word')
        n = len(n)
        s3 = string + (' ' + 'G3:' + str(n))
        print(s3)


def jac_sim(argA, argB):
    C = argA | argB
    D = argA & argB
    return len(D)/len(C)


def jac(docs):
    for i, a in enumerate(docs):
        for j, b in enumerate(docs):
            if i < j:
                sim = (jac_sim(a, b))
                string = 'JS(D{a}, D{b}):'.format(a=str(i+1), b=str(j+1))
                string += str(sim)
                print(string)
    print('-'*40)


def runB():
    paths = ['./data/D1.txt',
             './data/D2.txt',
             './data/D3.txt',
             './data/D4.txt']

    G1 = [k_gram(2, path, 'character') for path in paths]
    G2 = [k_gram(3, path, 'character') for path in paths]
    G3 = [k_gram(2, path, 'word') for path in paths]

    print('G1')
    jac(G1)
    print('G2')
    jac(G2)
    print('G3')
    jac(G3)


if __name__ == '__main__':
    # runA()
    runB()
