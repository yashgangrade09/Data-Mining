# !/usr/bin/env python3
# -*- coding:utf-8 -*-
#
# Author: Flyaway - flyaway1217@gmail.com
# Blog: zhouyichu.com
#
# Python release: 3.4.5
#
# Date: 2017-02-10 14:58:46
# Last modified: 2017-02-11 10:17:08

"""
Implement the min hashing algorithm.
"""

import random
import time

import matplotlib.pyplot as plt

from k_gram import k_gram


def generate_k_grams():
    paths = ['./data/D1.txt',
             './data/D2.txt']

    G2 = [k_gram(3, path, 'character') for path in paths]
    return G2


def generate_hashing(a, b, m=200000):
    def hashing(string):
        x = hash(string)
        return ((a*x)+b) % m
    return hashing


def hamming_dis(A, B):
    value = [int(a == b) for a, b in zip(A, B)]
    return sum(value)


def min_hash(G2, hash_num):
    a = 1
    b = hash_num * 10
    randint = random.randint

    # Generate the hashing functions
    hash_funcs = [generate_hashing(randint(a, b), randint(a, b))
                  for _ in range(hash_num)]

    signatures = []
    for kgrams in G2:
        vector = []
        for func in hash_funcs:
            value = min([func(elem) for elem in kgrams])
            vector.append(value)
        signatures.append(vector)

    vectorA = signatures[0]
    vectorB = signatures[1]

    return hamming_dis(vectorA, vectorB) / len(vectorA)


def plot(x, y):
    plt.plot(x, y)
    # plt.plot(x, [0.64]*len(x))
    plt.xlabel('t', fontsize=40)
    plt.ylabel('Time', fontsize=40)
    plt.show()


def run():
    G2 = generate_k_grams()
    T = list(range(10, 1010, 10))
    values = []
    times = []
    for t in T:
        start = time.clock()
        value = min_hash(G2, t)
        times.append(time.clock()-start)
        values.append(value)
    plot(T, times)

if __name__ == '__main__':
    run()
