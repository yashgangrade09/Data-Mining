# -*- coding: utf-8 -*-
"""
Created on Sat Feb 11 12:37:14 2017

@author: hhan
"""

import numpy
with open('./data/D1.txt', 'r') as file:
    data1 = file.read().replace('\n','')

with open('./data/D1.txt', 'r') as file:
    data2 = file.read()
    
d1g1 = set()
dlength = len(data1)
for i in range (dlength-1):
    d1g1.add(data1[i:i+2])

d1g12 = set()
dlength = len(data2)
for i in range (dlength-1):
    d1g12.add(data2[i:i+2])

print(d1g12 - d1g1)
