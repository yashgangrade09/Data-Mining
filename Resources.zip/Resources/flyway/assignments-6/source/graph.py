# !/usr/bin/env python3
# -*- coding:utf-8 -*-
#
# Author: Flyaway - flyaway1217@gmail.com
# Blog: zhouyichu.com
#
# Python release: 3.5.2
#
# Date: 2017-04-19 13:46:46
# Last modified: 2017-04-20 11:22:11

"""
Implementation for Markov Random Walk.
"""

import numpy as np
import numpy.linalg as LA


def read_matrix(path):
    with open(path, encoding='utf8') as f:
        matrix = []
        for line in f:
            s = line.strip().split()
            value = [float(v) for v in s]
            matrix.append(value)
    return np.array(matrix)


def MatrixPower(M, t, q):
    assert t > 1
    reval = M.dot(M)
    for _ in range(t-2):
        reval = reval.dot(M)
    print(reval)
    return reval.dot(q)


def StatePropagation(M, t, q):
    qx = M.dot(q)
    for _ in range(t-1):
        qx = M.dot(qx)
    return qx


def RandomWalk(M, i, t0, t):
    j = i
    for _ in range(t0):
        j = walk(M, j)

    record = [0] * M.shape[0]

    for _ in range(t):
        j = walk(M, j)
        record[j] += 1

    record = np.array(record)
    return record/np.sum(record)


def walk(M, i):
    p = M[:, i]
    x = np.array(range(M.shape[0]))
    j = np.random.choice(x, p=p)
    return j


def EigenAnalysis(M):
    W, V = LA.eig(M)
    V = V[:, 0]
    qstart = V/np.sum(V)
    return qstart


def A():
    path = './data/M.dat'
    t = 1024
    t0 = 100
    q0 = [0] * 10
    q0[0] = 1
    q0 = np.array(q0)

    M = read_matrix(path)

    q1 = MatrixPower(M, t, q0)
    q2 = StatePropagation(M, t, q0)
    q3 = RandomWalk(M, 0, t0, t)
    q4 = EigenAnalysis(M)

    s = 'Matrix Power:\t\t{a}'.format(a=str(q1))
    print(s)
    s = 'State Propagation:\t{a}'.format(a=str(q2))
    print(s)
    s = 'Random Walk: \t\t{a}'.format(a=str(q3))
    print(s)
    s = 'Eigen Analysis:\t\t{a}'.format(a=str(q4))
    print(s)


def B():
    path = './data/M.dat'
    M = read_matrix(path)
    t = 1024
    q0 = [0] * 10
    q0[0] = 1
    answer = MatrixPower(M, t, q0)

    q0 = [0.1] * 10
    for t in range(2, 2048):
        # q1 = MatrixPower(M, t, q0)
        q1 = StatePropagation(M, t, q0)
        delta = q1-answer
        if sum(abs(delta)) < 0.00000001:
            print(t)
            print(q1)
            print(answer)
            break

    # print('t={a}'.format(a=str(t)))
    # print('MatrixPower={a}'.format(a=str(q1)))


if __name__ == '__main__':
    A()
    # B()
