# !/usr/bin/env python3
# -*- coding:utf-8 -*-
#
# Author: Flyaway - flyaway1217@gmail.com
# Blog: zhouyichu.com
#
# Python release: 3.4.5
#
# Date: 2017-01-16 20:26:28
# Last modified: 2017-01-20 11:06:52

"""
Implementation for Birthday Paradox
"""

import random
import time

import matplotlib.pyplot as plt


def QA(n):
    s = set()
    count = 0
    while True:
        count += 1
        x = random.randint(1, n)
        if x in s:
            return count
        s.add(x)


def QB(m, n):
    result = [QA(n) for i in range(m)]
    result = sorted(result)
    return result


def density(result):
    """ Calculate the cumulative density.
    """
    unique = list(set(result))
    unique = sorted(unique)
    y = []
    for x in unique:
        count = len([i for i in result if i <= x])
        y.append(count/len(result))
    return unique, y


def plot(x, y):
    plt.plot(x, y)
    plt.xlabel('k - Number of trials required', fontsize=30)
    plt.ylabel('Probability of Collision', fontsize=30)
    plt.show()


def QD(m):
    x = [i for i in range(4000, 1000001, 1000)]
    y = []
    for n in x:
        t = time.clock()
        QB(m, n)
        y.append(time.clock()-t)
    return x, y


def write(path, x, y):
    with open(path, 'w', encoding='utf8') as f:
        for a, b in zip(x, y):
            s = ' '.join([str(a), str(b)])
            f.write(s+'\n')


def read(path):
    x = []
    y = []
    with open(path, encoding='utf8') as f:
        for line in f:
            s = line.strip().split()
            x.append(float(s[0]))
            y.append(float(s[1]))
    return x, y


if __name__ == '__main__':
    n = 4000
    m = 30000
    # print(QA(n))
    result = QB(m, n)
    # print(result)
    print(sum(result)/len(result))

    # x, y = density(result)
    # plot(x, y)
    # t = time.clock()
    # result = QB(m, n)
    # print(time.clock()-t)

    # x, y = QD(300)
    # write('300.txt', x, y)

    # x, y = QD(5150)
    # write('5150.txt', x, y)

    # x, y = QD(10000)
    # write('10000.txt', x, y)

    # x, y = read('10000.txt')
    # plot(x, y)
