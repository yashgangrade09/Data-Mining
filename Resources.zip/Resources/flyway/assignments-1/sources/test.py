
def cal(n, k):
    value = 1
    for i in range(1, k):
        value *= ((n-i)/n)
    return 1-value


def cal2(n, k):
    power = (k-1)*k /2
    return 1-((1-1/n)**power)

if __name__ == '__main__':
    # print(cal(4000, 75))
    print(cal2(4000, 76))

