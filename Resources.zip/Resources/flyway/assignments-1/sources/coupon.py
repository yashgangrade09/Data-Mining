# !/usr/bin/env python3
# -*- coding:utf-8 -*- #
# Author: Flyaway - flyaway1217@gmail.com
# Blog: zhouyichu.com
#
# Python release: 3.4.5
#
# Date: 2017-01-16 20:42:15
# Last modified: 2017-01-23 12:40:33

"""
Implementation for Coupon Collectors
"""

import random
import time

import matplotlib.pyplot as plt


def QA(n):
    count = n
    x = [random.randint(1, n) for _ in range(n)]
    s = set(x)
    while True:
        count += 1
        x = random.randint(1, n)
        s.add(x)
        if len(s) == n:
            return count


def QB(m, n):
    results = [QA(n) for i in range(m)]
    # results = sorted(results)
    return results


def density(result):
    """ Calculate the cumulative density.
    """
    unique = list(set(result))
    unique = sorted(unique)
    y = []
    for x in unique:
        count = len([i for i in result if i <= x])
        y.append(count/len(result))
    return unique, y


def plot(x, y):
    plt.plot(x, y)
    plt.xlabel('n', fontsize=40)
    plt.ylabel('Time', fontsize=40)
    plt.show()


def QD(m):
    x = [ i for i in range(200, 20001, 1000)]
    y = []
    for n in x:
        t = time.clock()
        QB(m, n)
        y.append(time.clock()-t)
    return x, y

def write(path, x, y):
    with open(path, 'w', encoding='utf8') as f:
        for a, b in zip(x, y):
            s = ' '.join([str(a), str(b)])
            f.write(s+'\n')


def read(path):
    x = []
    y = []
    with open(path, encoding='utf8') as f:
        for line in f:
            s = line.strip().split()
            x.append(float(s[0]))
            y.append(float(s[1]))
    return x, y


if __name__ == '__main__':
    n = 300
    m = 3000
    # print(QA(n))
    # result = QB(m, n)
    # print(sum(result)/len(result))

    # x, y = density(result)
    # plot(x, y)

    # t = time.clock()
    # QB(m, n)
    # print(time.clock()-t)

    # x, y =QD(5000)
    # write('coupon_5000.txt', x, y)
    x, y = read('coupon_5000.txt')
    plot(x, y)
