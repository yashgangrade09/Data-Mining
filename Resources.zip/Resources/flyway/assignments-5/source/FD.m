function [B] = FD(A,l)
  [n,d] = size(A);

  B = zeros(2*l,d);

  % fill in the rest here

end