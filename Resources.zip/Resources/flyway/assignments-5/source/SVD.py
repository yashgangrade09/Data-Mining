# !/usr/bin/env python3
# -*- coding:utf-8 -*-
#
# Author: Flyaway - flyaway1217@gmail.com
# Blog: zhouyichu.com
#
# Python release: 3.4.5
#
# Date: 2017-04-03 20:08:16
# Last modified: 2017-04-06 13:49:10

"""
Play with the SVD.
"""

import numpy as np
import numpy.linalg as LA
import matplotlib.pyplot as plt


def read(path):
    reval = []
    with open(path, encoding='utf8') as f:
        for line in f:
            if len(line.strip()) == 0:
                continue
            s = line.strip().split()
            vector = [float(v) for v in s]
            reval.append(vector)
    return np.array(reval)


def topKSVD(A, k):
    U, S, V = np.linalg.svd(A, full_matrices=False)
    S = np.diag(S)
    return U[:, :k], S[:k, :k], V[:k]
    # return U, S, V


def ProbA(path):
    A = read(path)
    for k in range(1, 11):
        Uk, Sk, Vk = topKSVD(A, k)
        Ak = np.dot(Uk, np.dot(Sk, Vk))
        delta = A-Ak
        print(LA.norm(delta, 2))


def ProbB(path):
    A = read(path)
    val = []
    for k in range(1, 31):
        Uk, Sk, Vk = topKSVD(A, k)
        Ak = np.dot(Uk, np.dot(Sk, Vk))
        delta = A-Ak
        val.append(LA.norm(delta, 2))

    valA = LA.norm(A, 2) * 0.1
    print(valA)
    for index, v in enumerate(val):
        if v < valA:
            print(index+1)
    print(val)


def ProbC(path):
    A = read(path)
    U2, S2, V2 = topKSVD(A, 2)

    X = np.dot(U2, S2)
    plot(X)


def plot(X):
    x = X[:, 0]
    y = X[:, 1]
    plt.plot(x, y)
    plt.show()


if __name__ == '__main__':
    pathA = './data/A.dat'
    ProbC(pathA)
