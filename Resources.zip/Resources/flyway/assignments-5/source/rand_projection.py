# !/usr/bin/env python3
# -*- coding:utf-8 -*-
#
# Author: Flyaway - flyaway1217@gmail.com
# Blog: zhouyichu.com
#
# Python release: 3.4.5
#
# Date: 2017-04-07 12:45:08
# Last modified: 2017-04-07 13:29:25

"""
Implementation of random projection.
"""

import numpy as np
import numpy.linalg as LA


def read(path):
    reval = []
    with open(path, encoding='utf8') as f:
        for line in f:
            if len(line.strip()) == 0:
                continue
            s = line.strip().split()
            vector = [float(v) for v in s]
            reval.append(vector)
    return np.array(reval)


def Error(A, B):
    return LA.norm(np.dot(A.transpose(), A)-np.dot(B.transpose(), B), 2)


def RandomProjection(A, l):
    n, d = A.shape
    S = np.random.normal(size=(l, n))
    # S = []
    # for x in P:
    #     S.append(x/LA.norm(x, 2))
    # S = np.array(S)
    S = S * (1/np.sqrt(l))
    return np.dot(S, A)


def probB(path):
    A = read(path)
    for l in range(1, 100):
        error = []
        for _ in range(100):
            B = RandomProjection(A, l)
            error.append(Error(A, B))
        error = np.array(error)
        e = sum(error) / len(error)
        var = np.var(error)
        print('l={a}, average error={b}, varance={c}'.format(
            a=str(l), b=str(e), c=str(var)))


if __name__ == '__main__':
    path = './data/A.dat'
    probB(path)
