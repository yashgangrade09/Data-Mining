# !/usr/bin/env python3
# -*- coding:utf-8 -*-
#
# Author: Flyaway - flyaway1217@gmail.com
# Blog: zhouyichu.com
#
# Python release: 3.4.5
#
# Date: 2017-04-06 20:43:08
# Last modified: 2017-04-06 21:54:35

"""
Linear regression
"""

import numpy as np
import numpy.linalg as LA


def LeastSquares(X, Y):
    XT = X.transpose()
    A = np.dot(XT, X)
    A = LA.inv(A)
    return np.dot(np.dot(A, XT), Y)


def RidgeRegression(X, Y, s):
    XT = X.transpose()
    A = np.dot(XT, X)
    B = np.dot((s**2), np.eye(12))
    A = A+B
    A = LA.inv(A)
    return np.dot(np.dot(A, XT), Y)


def read(path):
    reval = []
    with open(path, encoding='utf8') as f:
        for line in f:
            if len(line.strip()) == 0:
                continue
            s = line.strip().split()
            vector = [float(v) for v in s]
            reval.append(vector)
    return np.array(reval)


def Error(X, Y, C):
    return LA.norm(Y-np.dot(X, C), 2)


def probA(pathX, pathY):
    X = read(pathX)
    Y = read(pathY)
    # C = LeastSquares(X, Y)
    # error = LA.norm(Y-np.dot(X, C), 2)
    # print(error)

    S = [0.1, 0.3, 0.5, 1.0, 2.0]
    for s in S:
        Cs = RidgeRegression(X, Y, s)
        error = Error(X, Y, Cs)
        print('s={a}, error={b}'.format(a=str(s), b=str(error)))


def subset(X, Y):
    # X1 = X[0:33, :]
    # Y1 = Y[0:33]

    # X2 = X[66:100, :]
    # Y2 = Y[66:100]

    # rX1 = X[33:66, :]
    # rY1 = Y[33:66]

    # X1 = np.vstack((X1, X2))
    # Y1 = np.vstack((Y1, Y2))

    # X1
    # X1 = X[0:66, :]
    # Y1 = Y[0:66]

    # rX1 = X[66:, :]
    # rY1 = Y[66:]

    # X2
    X1 = X[33:100, :]
    Y1 = Y[33:100]

    rX1 = X[0:33, :]
    rY1 = Y[0:33]

    return X1, Y1, rX1, rY1


def probB(pathX, pathY):
    X = read(pathX)
    Y = read(pathY)

    X1, Y1, rX1, rY1 = subset(X, Y)
    S = [0.1, 0.3, 0.5, 1.0, 2.0]
    for s in S:
        Cs = RidgeRegression(X1, Y1, s)
        error = Error(rX1, rY1, Cs)
        print('s={a}, error={b}'.format(a=str(s), b=str(error)))

    # error = Error(rX1, rY1, C)
    # print(error)


if __name__ == '__main__':
    pathX = './data/X.dat'
    pathY = './data/Y.dat'
    probB(pathX, pathY)
