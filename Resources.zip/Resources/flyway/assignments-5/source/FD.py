# !/usr/bin/env python3
# -*- coding:utf-8 -*-
#
# Author: Flyaway - flyaway1217@gmail.com
# Blog: zhouyichu.com
#
# Python release: 3.4.5
#
# Date: 2017-04-07 10:24:46
# Last modified: 2017-04-07 11:30:05

"""
Frequent Direction
"""

import numpy as np
import numpy.linalg as LA


def diag(S, l):
    delta = S[l-1] ** 2
    reval = []
    for index, v in enumerate(S):
        if index < l:
            reval.append(np.sqrt(v**2-delta))
        else:
            reval.append(0)
    reval = np.array(reval)
    return np.diag(reval)


def Error(A, B):
    return LA.norm(np.dot(A.transpose(), A)-np.dot(B.transpose(), B), 2)


def FD(A, l):
    n, d = A.shape
    B = np.zeros((2*l, d))

    for ai in A:
        for index in range(B.shape[0]):
            if sum(B[index]) == 0:
                break
        else:
            [U, S, V] = LA.svd(B, full_matrices=False)
            Sp = diag(S, l)
            B = np.dot(Sp, V)
        B[index] = ai
    return B


def test(A):
    [U, S, V] = LA.svd(A, full_matrices=False)
    S = np.diag(S)
    AA = np.dot(np.dot(U, S), V)
    print(A)
    print('-'*50)
    print(AA)


def read(path):
    reval = []
    with open(path, encoding='utf8') as f:
        for line in f:
            if len(line.strip()) == 0:
                continue
            s = line.strip().split()
            vector = [float(v) for v in s]
            reval.append(vector)
    return np.array(reval)


def probA(path):
    A = read(path)
    # A2 = topKSVD(A, 2)
    # limit = (LA.norm(A, 'fro') ** 2) / 3
    # limit = (LA.norm(A-A2, 'fro')**2)/10
    # print('limit={a}'.format(a=str(limit)))
    for l in range(1, 11):
        limit = (LA.norm(A, 'fro') ** 2) / l
        print('limit={a}'.format(a=str(limit)))
        B = FD(A, l)
        error = Error(A, B)
        print('l={a}, error={b}'.format(a=str(l), b=str(error)))
        print('-'*10)


def topKSVD(A, k):
    U, S, V = np.linalg.svd(A, full_matrices=False)
    S = np.diag(S)
    Uk, Sk, Vk = U[:, :k], S[:k, :k], V[:k]
    Ak = np.dot(Uk, np.dot(Sk, Vk))
    return Ak


if __name__ == '__main__':
    path = './data/A.dat'
    probA(path)
