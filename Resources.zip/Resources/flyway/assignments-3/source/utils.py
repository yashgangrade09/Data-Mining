# !/usr/bin/env python3
# -*- coding:utf-8 -*-
#
# Author: Flyaway - flyaway1217@gmail.com
# Blog: zhouyichu.com
#
# Python release: 3.4.5
#
# Date: 2017-02-22 14:22:03
# Last modified: 2017-02-26 09:53:41

"""
Util functions for clustering.
"""

import numpy as np
import matplotlib.pyplot as plt


def read(path):
    points = []
    with open(path, encoding='utf8') as f:
        for index, line in enumerate(f):
            s = line.split()
            point = s[1:]
            point = np.array([float(v) for v in point])
            points.append(point)
    return points


def plot(points, axis=None):
    x = [v[0] for v in points]
    y = [v[1] for v in points]
    plt.scatter(x, y)
    if axis is not None:
        plt.axis(axis)
    plt.show()


def plot_cluster(list_points, size=50, axis=None):
    """Plot all the clusters

    Args:
        list_points: list(list(point))
    """
    colors = ['red', 'blue', 'green', 'black']
    for color, points in zip(colors, list_points):
        x = [v[0] for v in points]
        y = [v[1] for v in points]
        plt.scatter(x, y, s=size, color=color)
    if axis is not None:
        plt.axis(axis)
    plt.show()


def collect_clusters(points, mappings):
    """Transform the mappings into a list of clusters.
    """
    assert len(points) == len(mappings)
    n = len(points)
    tmp_mapping = dict()

    for i in range(n):
        if mappings[i] not in tmp_mapping:
            tmp_mapping[mappings[i]] = []
        tmp_mapping[mappings[i]].append(points[i])

    reval = list(tmp_mapping.values())
    return reval


def collect_centers(points, mappings):
    centers = set(mappings)
    centers = [points[i] for i in centers]
    return centers


def norm2(a, b):
    """Calculate the norm2 distance between a and b.
    Args:
        a: np.array
        b. np.array

    Returns:
        float
    """
    return np.sqrt(sum((a-b)**2))


def cost(points, mapping, centers, dis):
    n = len(points)
    diss = [dis(points[i], centers[mapping[i]]) for i in range(n)]
    diss = np.array(diss)
    max_cost = max(diss)

    mean_cost = np.sqrt(sum(diss**2)/n)

    return max_cost, mean_cost


def density(result):
    """ Calculate the cumulative density.
    """
    unique = list(set(result))
    unique = sorted(unique)
    y = []
    for x in unique:
        count = len([i for i in result if i <= x])
        y.append(count/len(result))
    return unique, y


def plot_density(x, y):
    plt.plot(x, y)
    plt.xlabel('3-mean cost', fontsize=40)
    plt.ylabel('Prob', fontsize=40)
    plt.axis([4, 30, 0.5, 1.0])
    plt.show()
