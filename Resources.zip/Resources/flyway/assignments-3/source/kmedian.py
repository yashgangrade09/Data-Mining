# !/usr/bin/env python3
# -*- coding:utf-8 -*-
#
# Author: Flyaway - flyaway1217@gmail.com
# Blog: zhouyichu.com
#
# Python release: 3.4.5
#
# Date: 2017-02-25 15:29:39
# Last modified: 2017-03-01 10:05:44

"""
K-median implementation.
"""

import numpy as np

import utils
import Kmeanpp


class Kmedia:
    """The class for k-means clustering.
    """
    def __init__(self, dis_func=None):
        if dis_func is None:
            self._dis_func = utils.norm2
        else:
            self._dis_func = dis_func

    def clustering(self, points, k, max_iter, init_centers=None):
        """Run the k-means algorithm.

        There are three conditions to terminate the clustering
        porcess:
        1. The number of changed centers between two
           interations is small enough.
        2. The interation time is larger than the max iteration time.
        3. Between 2 iterations, there no difference in centers.

        Args:
            points: list(np.array) - A list of points need to be clustered.
            k: int - The number of clusters.
            max_iter: int - The max iteration time.
            init_centers: list(np.array) - A list of initial centers
                          with size k.
        Returns:
            mapping: list(int) - mapping[i] records
                     index of the center for i-th point.
            centers: list(np.array) - A list of centers.
        """
        if init_centers is None:
            centers = self._initialize_centers(points, k)
        else:
            assert len(init_centers) == k
            centers = init_centers
        old_centers = None
        counter = 0
        while counter <= max_iter and self._diff(old_centers, centers) > 0:
            old_centers = centers[:]
            mapping = self._assign_closest(points, old_centers)

            # clusters = utils.collect_clusters(points, mapping)
            # utils.plot_cluster(clusters)

            centers = self._generate_centers(points, mapping, k)
            counter += 1

        return mapping, centers

    def _initialize_centers(self, points, k):
        """Initialze the k centers.

        Returns:
            centers: list(np.array) - A list of points with size k.
        """
        # Use first k points as the initial centers
        centers = points[:k]

        assert len(centers) == k
        return centers

    def _assign_closest(self, points, centers):
        """Assign each point to its centers.

        Args:
            points: list(np.array) - A list of points
            centers: list(np.array) - A list of centers.

        Returns:
            mapping: list(int) - A mapping from each point
                        to its center.
        """
        mapping = [-1] * len(points)
        dis_func = self._dis_func
        for i, p in enumerate(points):
            diss = [(dis_func(p, c), j) for j, c in enumerate(centers)]
            mapping[i] = min(diss, key=lambda x: x[0])[-1]
        return mapping

    def _generate_centers(self, points, mapping, k):
        """Generate the new centers given the old centers.

        Args:
            points: list(np.array) - A list of points.
            mapping: list(int) - A mapping from each point to its center.
        """
        assert len(points) == len(mapping)
        centers = []
        for i in range(k):
            subsets = np.array([points[j] for j, val in enumerate(mapping)
                                if val == i])
            centers.append(np.median(subsets, axis=0))
            # centers.append(subsets.mean(axis=0))
        print(centers)
        print('-'*50)
        return centers

    def _diff(self, old_centers, centers):
        """Compare the centers bwtween two iterations.

        Args:
            old_centers: list(np.array) - A list of centers.
            centers: list(np.array) - A list of centers.

        Returns:
            float - The fraction of difference centers.
        """
        if old_centers is None:
            return len(centers)
        assert len(old_centers) == len(centers)
        counter = 0
        counter = sum([1 for p, q in zip(old_centers, centers)
                       if ((p == q).all())])
        n = len(old_centers)
        return (n-counter) / n


def cost1(points, mapping, centers, dis):
    n = len(points)
    diss = [dis(points[i], centers[mapping[i]]) for i in range(n)]
    diss = np.array(diss)

    cost = sum(diss) / len(diss)

    return cost


def write(centers, path):
    with open(path, 'w', encoding='utf8') as f:
        for i, p in enumerate(centers):
            s = p.tolist()
            s = [i+1] + s
            s = [str(v) for v in s]
            f.write(' '.join(s)+'\n')


if __name__ == '__main__':
    path = './data/C3.txt'
    points = utils.read(path)
    clus = Kmedia(utils.norm2)
    k = 4

    reval = []
    min_cost = float('INF')
    for _ in range(1):
        kmeans_mapping = Kmeanpp.Kmeans(points, k, utils.norm2)
        init_centers = utils.collect_centers(points, kmeans_mapping)

        mapping, centers = clus.clustering(points, k, 100, init_centers)
        cost = cost1(points, mapping, centers, utils.norm2)
        if cost < min_cost:
            min_cost = cost
            min_centers = centers
    print(min_cost)
    write(min_centers, 'k-median-tmp.txt')
