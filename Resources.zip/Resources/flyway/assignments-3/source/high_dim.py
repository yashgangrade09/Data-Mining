# !/usr/bin/env python3
# -*- coding:utf-8 -*-
#
# Author: Flyaway - flyaway1217@gmail.com
# Blog: zhouyichu.com
#
# Python release: 3.4.5
#
# Date: 2017-02-25 14:55:15
# Last modified: 2017-02-25 15:04:37

"""
High dimensional distance
"""

import math
import matplotlib.pyplot as plt


def C(d):
    x = 2 ** d
    y = math.gamma(d/2 + 1)
    z = math.pi ** (d / 2)
    return (x*y/z)**(1/d)


def plot(x, y):
    plt.plot(x, y)
    plt.xlabel('value of d', fontsize=40)
    plt.ylabel('value of c', fontsize=40)
    plt.show()


if __name__ == '__main__':
    x = list(range(1, 21))
    y = [C(val) for val in x]
    plot(x, y)
