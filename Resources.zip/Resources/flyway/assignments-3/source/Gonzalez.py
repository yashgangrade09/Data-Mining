# !/usr/bin/env python3
# -*- coding:utf-8 -*-
#
# Author: Flyaway - flyaway1217@gmail.com
# Blog: zhouyichu.com
#
# Python release: 3.4.5
#
# Date: 2017-02-22 14:05:17
# Last modified: 2017-02-25 09:38:50

"""
Naive implementation of Gonzalez algorithm.
"""

import numpy as np

import utils


def clustering(points, k, dis):
    """
    Args:
        points: list(np.array)
        k: int

    Returns:
        mapping: list(int) - mapping[i] represent the center of i-th point.
        C: list(int) - Record the center for each cluster.
    """
    mapping = [0] * len(points)
    n = len(points)

    for i in range(1, k):
        M = 0
        center = 0
        # Find the farest point
        for j in range(n):
            d = dis(points[j], points[mapping[j]])
            if d > M:
                M = d
                center = j

        # Updating the mapping table
        for j in range(n):
            d = dis(points[j], points[center])
            if dis(points[j], points[mapping[j]]) > d:
                mapping[j] = center
    return mapping


def cost(points, mapping, centers, dis):
    n = len(points)
    dis = [dis(points[i], centers[mapping[i]]) for i in range(n)]
    dis = np.array(dis)
    max_cost = max(dis)

    mean_cost = np.sqrt(sum(dis**2)/n)

    return max_cost, mean_cost


if __name__ == '__main__':
    path = './data/C2.txt'
    points = utils.read(path)
    # utils.plot(points)
    mappings = clustering(points, k=3, dis=utils.norm2)
    max_cost, mean_cost = cost(points, mappings, points, utils.norm2)
    centers = utils.collect_centers(points, mappings)
    print('max_cost={a}, mean_cost={b}'.format(a=max_cost, b=mean_cost))
    print('centers:' + str(centers))

    clusters = utils.collect_clusters(points, mappings)
    # print(len(clusters))
    utils.plot_cluster(clusters)
