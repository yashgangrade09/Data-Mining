# !/usr/bin/env python3
# -*- coding:utf-8 -*-
#
# Author: Flyaway - flyaway1217@gmail.com
# Blog: zhouyichu.com
#
# Python release: 3.4.5
#
# Date: 2017-02-23 14:15:43
# Last modified: 2017-02-26 09:53:12

"""
Naive implementation of Lloyd's clusters.
"""

# import random

import numpy as np

import utils
import Kmeanpp


class Lloyd:
    """The class for k-means clustering.
    """
    def __init__(self, dis_func=None):
        if dis_func is None:
            self._dis_func = utils.norm2
        else:
            self._dis_func = dis_func

    def clustering(self, points, k, max_iter, init_centers=None):
        """Run the k-means algorithm.

        There are three conditions to terminate the clustering
        porcess:
        1. The number of changed centers between two
           interations is small enough.
        2. The interation time is larger than the max iteration time.
        3. Between 2 iterations, there no difference in centers.

        Args:
            points: list(np.array) - A list of points need to be clustered.
            k: int - The number of clusters.
            max_iter: int - The max iteration time.
            init_centers: list(np.array) - A list of initial centers
                          with size k.
        Returns:
            mapping: list(int) - mapping[i] records
                     index of the center for i-th point.
            centers: list(np.array) - A list of centers.
        """
        if init_centers is None:
            centers = self._initialize_centers(points, k)
        else:
            assert len(init_centers) == k
            centers = init_centers
        old_centers = None
        counter = 0
        while counter <= max_iter and self._diff(old_centers, centers) > 0:
            old_centers = centers[:]
            mapping = self._assign_closest(points, old_centers)

            # clusters = utils.collect_clusters(points, mapping)
            # utils.plot_cluster(clusters)

            centers = self._generate_centers(points, mapping, k)
            counter += 1

        return mapping, centers

    def _initialize_centers(self, points, k):
        """Initialze the k centers.

        Returns:
            centers: list(np.array) - A list of points with size k.
        """
        # Use first k points as the initial centers
        centers = points[:k]

        assert len(centers) == k
        return centers

    def _assign_closest(self, points, centers):
        """Assign each point to its centers.

        Args:
            points: list(np.array) - A list of points
            centers: list(np.array) - A list of centers.

        Returns:
            mapping: list(int) - A mapping from each point
                        to its center.
        """
        mapping = [-1] * len(points)
        dis_func = self._dis_func
        for i, p in enumerate(points):
            diss = [(dis_func(p, c), j) for j, c in enumerate(centers)]
            mapping[i] = min(diss, key=lambda x: x[0])[-1]
        return mapping

    def _generate_centers(self, points, mapping, k):
        """Generate the new centers given the old centers.

        Args:
            points: list(np.array) - A list of points.
            mapping: list(int) - A mapping from each point to its center.
        """
        assert len(points) == len(mapping)
        centers = []
        for i in range(k):
            subsets = np.array([points[j] for j, val in enumerate(mapping)
                                if val == i])
            centers.append(subsets.mean(axis=0))
        return centers

    def _diff(self, old_centers, centers):
        """Compare the centers bwtween two iterations.

        Args:
            old_centers: list(np.array) - A list of centers.
            centers: list(np.array) - A list of centers.

        Returns:
            float - The fraction of difference centers.
        """
        if old_centers is None:
            return len(centers)
        assert len(old_centers) == len(centers)
        counter = 0
        counter = sum([1 for p, q in zip(old_centers, centers)
                       if ((p == q).all())])
        n = len(old_centers)
        return (n-counter) / n


def compare(clusterA, clusterB):
    """Compare two clusters.
    """
    if len(clusterB) != len(clusterA):
        return False
    try:
        for subset in clusterA:
            if subset not in clusterB:
                return False
        for subset in clusterB:
            if subset not in clusterA:
                return False
    except ValueError:
        print(subset)
    return True


def run():
    path = './data/C2.txt'
    points = utils.read(path)

    clus = Lloyd()
    k = 3

    # init_centers = points[:k]

    # init_centers = []
    # init_centers.append(points[0])
    # init_centers.append(points[-1])
    # init_centers.append(points[533])

    mean_val = []
    max_val = []
    counter = 0
    for _ in range(500):
        kmeans_mapping = Kmeanpp.Kmeans(points, k, utils.norm2)
        kmean_cluster = utils.collect_clusters(points, kmeans_mapping)

        init_centers = utils.collect_centers(points, kmeans_mapping)
        mapping, centers = clus.clustering(points, k, 50, init_centers)
        clusters = utils.collect_clusters(points, mapping)

        if compare(clusters, kmean_cluster):
            counter += 1

        # print(centers)
        # clusters = utils.collect_clusters(points, mapping)
        # utils.plot_cluster(clusters)
        max_cost, mean_cost = utils.cost(points, mapping, centers, utils.norm2)
        mean_val.append(mean_cost)
        max_val.append(max_cost)

    s = 'There are {a} times that subsets are the same as the with K-means'
    print(s.format(a=str(counter)))

    x, y = utils.density(mean_val)
    utils.plot_density(x, y)


if __name__ == '__main__':
    run()
    # path = './data/C2.txt'
    # points = utils.read(path)

    # clus = Lloyd()
    # k = 3

    # init_centers = points[:k]
    # init_centers = []
    # init_centers.append(points[0])
    # init_centers.append(points[-1])
    # init_centers.append(points[533])

    # mapping, centers = clus.clustering(points, k, 50, init_centers)
    # max_cost, mean_cost = utils.cost(points, mapping, centers, utils.norm2)

    # print(mean_cost)
