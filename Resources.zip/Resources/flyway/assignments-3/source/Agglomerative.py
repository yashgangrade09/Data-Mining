# !/usr/bin/env python3
# -*- coding:utf-8 -*-
#
# Author: Flyaway - flyaway1217@gmail.com
# Blog: zhouyichu.com
#
# Python release: 3.4.5
#
# Date: 2017-02-21 14:14:49
# Last modified: 2017-02-23 12:48:28

"""
Implementation of Agglomerative Clustering Algorithm  in a naive way.
"""

import numpy as np

import utils


class Distance:
    """ A collection of distance functions.
    """
    def __init__(self):
        pass

    def single_link(self, clusterA, clusterB):
        shortest = float('INF')
        for a in clusterA.points:
            for b in clusterB.points:
                dis = np.sqrt(np.sum((a-b)**2))
                if dis < shortest:
                    shortest = dis
        return shortest

    def complete_link(self, clusterA, clusterB):
        longest = float('-INF')
        for a in clusterA.points:
            for b in clusterB.points:
                dis = np.sqrt(np.sum((a-b)**2))
                if dis > longest:
                    longest = dis
        return longest

    def mean_link(self, clusterA, clusterB):
        a = clusterA.mean
        b = clusterB.mean
        return np.sqrt(np.sum((a-b)**2))


class Cluster:
    """The Cluster class.
    """
    def __init__(self, ID, points):
        """Construct a new cluster using the points.
        Args:
            ID: int - The identity of the cluster.
            points: numpy.array - A list of points.
        """
        self._ID = ID
        self._points = points[:]

    def union(self, other_cluster):
        """ Combine two clusters

        Args:
            other_cluster: Cluster - Cluster need to be combined.
        """
        self._points += other_cluster._points

    @property
    def mean(self):
        mean = sum(self._points)
        return mean / len(self._points)

    @property
    def ID(self):
        return self._ID

    @property
    def points(self):
        return self._points

    ########################################################
    # Magic methods
    ########################################################
    def __eq__(self, other):
        return other.ID == self.ID

    def __hash(self):
        return hash(self.ID)

    def __repr__(self):
        s = []
        for point in self._points:
            s.append(str(point.tolist()))
        return ' '.join(s)

    def __len__(self):
        return len(self._points)


def clustering(points, distance, k):
    """
    Args:
        points: list(np.array()) - A list of point.
        distance: function
        k: int
    Returns:
        a list of Cluster.
    """

    # Initialize
    clusters = [Cluster(i, [point]) for i, point in enumerate(points)]

    while len(clusters) > k:
        ii = -1
        jj = -1
        closest = float('INF')
        for i in range(len(clusters)):
            for j in range(i+1, len(clusters)):
                dis = distance(clusters[i], clusters[j])
                if dis < closest:
                    ii = i
                    jj = j
                    closest = dis
        a = clusters[ii]
        b = clusters[jj]
        a.union(b)
        del clusters[jj]
    return clusters


if __name__ == '__main__':
    path = './data/C1.txt'
    points = utils.read(path)
    # utils.plot(points, [-15,  10,  -6,  6])
    dis = Distance()
    reval = clustering(points, dis.mean_link, 4)

    # for i, val in enumerate(reval):
    #     print((i, val))

    list_points = [v.points for v in reval]
    utils.plot_cluster(list_points, 150, [-15, 10, -6, 6])
