# !/usr/bin/env python3
# -*- coding:utf-8 -*-
#
# Author: Flyaway - flyaway1217@gmail.com
# Blog: zhouyichu.com
#
# Python release: 3.4.5
#
# Date: 2017-02-24 13:19:13
# Last modified: 2017-02-26 10:10:35

"""
Naive implementation of K-means clustering.
"""

import random

import numpy as np

import utils
import Gonzalez


def Kmeans(points, k, dis_func):
    """Implement the k-means clustering.

    Args:
        points: list(np.array) - A list of points.
        k: int - The number of clusters
        dis_func: func - The distance function.

    Return:
        mapping:list(int)  - A list indicating the center of i-th point.
    """
    n = len(points)
    center = random.randint(0, n-1)
    mapping = [center] * len(points)
    centers = [points[center]]

    for i in range(1, k):
        weights = [dis_func(points[j], points[mapping[j]])**2
                   for j in range(n)]
        weights = [val/sum(weights) for val in weights]

        center = np.random.choice(list(range(n)), p=weights)
        centers.append(points[center])

        # Updating the mapping table
        for j in range(n):
            d = dis_func(points[j], points[center])
            if dis_func(points[j], points[mapping[j]]) > d:
                mapping[j] = center

    assert k == len(centers)
    return mapping


# def compare(clusterA, clusterB):
#     """Compare two clusters.
#     """
#     if len(clusterB) != len(clusterA):
#         return False
#     for subset in clusterA:
#         if subset not in clusterB:
#             return False
#     for subset in clusterB:
#         if subset not in clusterA:
#             return False
#     return True


def run():
    path = './data/C2.txt'
    points = utils.read(path)
    mean_val = []
    max_val = []

    go_mapping = Gonzalez.clustering(points, k=3, dis=utils.norm2)
    # go_clusters = utils.collect_clusters(points, mapping)
    counter = 0

    for _ in range(1000):
        mapping = Kmeans(points, 3, utils.norm2)
        max_cost, mean_cost = utils.cost(points, mapping, points, utils.norm2)
        mean_val.append(mean_cost)
        max_val.append(max_cost)

        # clusters = utils.collect_clusters(points, mapping)
        # utils.plot_cluster(clusters)
        if go_mapping == mapping:
            counter += 1

    var_max = np.array(max_val)
    var_max = np.var(var_max)

    var_mean = np.array(mean_val)
    var_mean = np.var(var_mean)
    print('Variation of 3-center cost:{a}'.format(a=var_max))
    print('Variation of 3-mean cost:{a}'.format(a=var_mean))
    s = 'There are {a} times that subsets are the same as the with Gonzalez'
    print(s.format(a=str(counter)))

    print(mean_val)

    # x, y = utils.density(mean_val)
    # utils.plot_density(x, y)


if __name__ == '__main__':
    run()
