i=0
while 1:


	i=i+1
	print 'I value is :', i
	if i==30:
		break	