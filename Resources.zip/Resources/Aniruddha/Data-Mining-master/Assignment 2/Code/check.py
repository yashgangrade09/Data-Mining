s='abcdefghijklm'
print 'Length of the string is :',len(s)
for i in range(0,len(s)):
	print i, s[i]