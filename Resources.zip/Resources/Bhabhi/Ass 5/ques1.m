load A.dat
%centered data
% sum1 = sum(A);
% for i = 1:30
%     A(:,i) = A(:,i)/sum1(1,i);
% end
[U,S,V] = svd(A); % A = m X n
% n = 10;
% normSVD = ones(n,1);
% for k = 1:n
%     [ Ak ] = calculateSVD( U,S,V,k );
%     normSVD(k,1) = norm(A-Ak,2);
%     temp = norm(A);
% end

X = U(:,1)*S(1,1);
Y = U(:,2)*S(2,2);
scatter(X,Y);


