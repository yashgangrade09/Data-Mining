clear;
load X.dat
load Y.dat
[~,d] = size(X);

% X1 = X(1:66,:);
% Y1 = Y(1:66,:);
% Y2 = Y(67:100,:);
% X2 = X(67:100,:);
% X1 = X;
% Y1 = Y;
% Y2 = Y;
% X2 = X;

% X1 = X(34:100,:);
% Y1 = Y(34:100);
% Y2 = Y(1:33,:);
% X2 = X(1:33,:);

X1 = [X(1:33,:); X(67:100,:)];
Y1 = [Y(1:33); Y(67:100)];
Y2 = Y(34:66,:);
X2 = X(34:66,:);



S = [0.1 0.3 0.5 1.0 2.0];
A = pinv(X1'*X1)*X1' * Y1;
errorA = norm(Y2 - X2*A,2);
[~,n] = size(S);
errorAs = zeros(n,1);
for i = 1:n
    As = pinv(X1'*X1 + S(1,i)^2*eye(d))*X1'*Y1;
    errorAs(i,1) = norm(Y2 - X2*As,2);
end

%Part 2


