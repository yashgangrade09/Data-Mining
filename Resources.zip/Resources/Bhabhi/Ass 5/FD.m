function [B] = FD(A,L)
    [n,d] = size(A);

    B = zeros(L,d);
    B(1:L-1,:) = A(1:L-1,:);
    for i = L:n
        B(L,:) = A(i,:);
        [~,S,V] = svd(B);
        delta= S(L,L)^2;
        if delta ~= 0
            diagnalS = diag(S);
            diagnalS = sqrt(diagnalS.^2-delta);
            if d-L > 0
                 newS = [diag(diagnalS) zeros(L,d-L)];
            else
                newS = diag(diagnalS);
            end
        else
            newS = S;
        end
        B = newS* V'; 
    end
end