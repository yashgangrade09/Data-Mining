clear 
close all
load A.dat

maximum_error = (norm(A, 'fro')^2)/10;

[U,S,V] = svd(A); % A = m X n



for L = 2:10
    [B] = FD(A,L); %best rank L-1 matrix
%     %error = norm(A'*A - B'*B, 2);
%     if error < maximum_error
%         break
%     end
    for k = 1:L
        Bk = B(1:k,:);
        APBk = A * pinv(Bk)*Bk;
        Ak = calculateSVD( U,S,V,k );
        error = norm(A-APBk, 'fro')^2;
        max_error = (norm(A-Ak, 'fro')^2)*1.1;
        if error < max_error        
            print= ['k: ',num2str(k),' L: ',num2str(L),' Error ',num2str(error), ' Max_Error: ',num2str(max_error)];
            disp(print);
        end
    end
end

disp(L);