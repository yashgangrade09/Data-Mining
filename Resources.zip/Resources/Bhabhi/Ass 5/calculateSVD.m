function [ Ak ] = calculateSVD( U,S,V,k )
    Uk = U(:,1:k); %Uk = m X k
    Sk = S(1:k,1:k);  %Sk = k X k
    Vk = V(:,1:k);    %Vk = n X k
    Ak = Uk*Sk*Vk';   %Ak = m X n
end

