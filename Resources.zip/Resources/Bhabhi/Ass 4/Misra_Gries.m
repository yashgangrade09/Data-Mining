%input: data
%K: k- 1 counters
%Output: C: Counter
%L: Location
function [ C,L ] = Misra_Gries( data,k )
    C = zeros(k,1);
    L = zeros(k,1);
    [m,~] = size(data);
    for i = 1:m
        current = data(i,1);
        index = find(L == current);
        [c,~] = size(index);
        if c == 0   
            flag = 0;
            for j = 1:k
                if L(j,1) == 0
                    C(j,1) = 1;
                    L(j,1) = current;
                    flag = 1;
                    break;
                end
            end
            if flag == 0
                C = C-1;
            end
            for j = 1:k
                if C(j,1) <=0
                    L(j,1)=0;
                end
            end 
        elseif c ~= 1
            disp('Error')
            return
        else
            C(index,1) = C(index,1)+1;
        end
        
            
    end

end

