function [ C ] = count_min( data,k,t )
    [m,~] = size(data);
    C = zeros(t,k);
    %random hash function parameters
    MM = [1000 100000 20000 200000 300000];
    AA = [10101.010 38.159 104.847 30.7 116.531]; 
   
    for i = 1:m
        current = data(i,1);
         for j = 1:t
            index = (floor(MM(1,j) * (current*AA(1,j) - floor(current*AA(1,j)))));
            index = mod(index,k);
            C(j,index+1) = C(j,index+1) + 1;
         end
    end


end

