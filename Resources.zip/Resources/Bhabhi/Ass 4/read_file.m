function [ data ] = read_file( file_name)
    fid = fopen(file_name);
    i =1;
    while(1)
        temp= fscanf(fid, '%c',1);
        if temp
            fscanf(fid, '%c',1);
            data(i,1) = temp;
            i = i+1;
        else
            break;
        end
    end
end