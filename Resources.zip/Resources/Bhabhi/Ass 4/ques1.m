file_name_1= 'S11.txt';
file_name_2 = 'S22.txt';
[ data1 ] = read_file( file_name_1);
[ data2 ] = read_file( file_name_2);
[ word_count ] = wordCount( data1 );
word_count = word_count';
[ word_count1 ] = wordCount( data2 );
word_count1 = word_count1';

k = 9;
[ C,L ] = Misra_Gries( data1,k );
L = char(L);
[ C1,L1 ] = Misra_Gries( data2,k );
L1 = char(L1);
