function [ word_count ] = wordCount( data )
    [m,~] = size(data);
    mapObj = containers.Map();
    for i = 1:m
        if isKey(mapObj,data(i))
            mapObj(data(i)) = mapObj(data(i))+1;
        else
            mapObj(data(i)) = 1;
        end
    end
 word_count = [mapObj.keys() ; mapObj.values()];
end

