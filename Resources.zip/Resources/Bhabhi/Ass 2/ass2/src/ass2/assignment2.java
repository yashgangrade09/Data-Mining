package ass2;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Random;
import java.util.Scanner;
import java.util.Set;

public class assignment2 {

	public static void main(String[] args) throws IOException, NoSuchAlgorithmException {
		// TODO Auto-generated method stub
		String[] file_names = {"D1.txt", "D2.txt", "D3.txt" , "D4.txt"};
		ArrayList<HashSet<String>> two_gram = new ArrayList<HashSet<String>>();
		ArrayList<HashSet<String>> three_gram = new ArrayList<HashSet<String>>();
		ArrayList<HashSet<String>> three_gram_words = new ArrayList<HashSet<String>>();
		
		//Ques 1(a)
		for(int i = 0 ;i< file_names.length; i++){
			String data = Read_File(file_names[i]);
			two_gram.add(build_2_gram (data));
			three_gram.add(build_3_gram (data));
			three_gram_words.add(build_3_gram_words (data));

			System.out.println("Number of 2 grams in document " + (i+1) + " is: " + two_gram.get(i).size());
			System.out.println("Number of 3 grams in document " + (i+1) + " is: " + three_gram.get(i).size());
			System.out.println("Number of 3 grams words in document " + (i+1) + " is: " + three_gram_words.get(i).size());
		}
		//Ques 1(b)
		//Jacard Similarity
		for(int i = 0;i<3;i++){
			//i = 0 === 2-grams
			if (i == 0)
			{
				System.out.println("JS between Doc 1 and Doc 2 for 2-grams: " + jacard_similarity(two_gram.get(0),two_gram.get(1)));
				System.out.println("JS between Doc 1 and Doc 3 for 2-grams: " + jacard_similarity(two_gram.get(0),two_gram.get(2)));
				System.out.println("JS between Doc 1 and Doc 4 for 2-grams: " + jacard_similarity(two_gram.get(0),two_gram.get(3)));
				System.out.println("JS between Doc 2 and Doc 3 for 2-grams: " + jacard_similarity(two_gram.get(1),two_gram.get(2)));
				System.out.println("JS between Doc 2 and Doc 4 for 2-grams: " + jacard_similarity(two_gram.get(1),two_gram.get(3)));
				System.out.println("JS between Doc 3 and Doc 4 for 2-grams: " + jacard_similarity(two_gram.get(2),two_gram.get(3)));				
			}
			if (i == 1)
			{
				System.out.println("JS between Doc 1 and Doc 2 for 3-grams: " + jacard_similarity(three_gram.get(0),three_gram.get(1)));
				System.out.println("JS between Doc 1 and Doc 3 for 3-grams: " + jacard_similarity(three_gram.get(0),three_gram.get(2)));
				System.out.println("JS between Doc 1 and Doc 4 for 3-grams: " + jacard_similarity(three_gram.get(0),three_gram.get(3)));
				System.out.println("JS between Doc 2 and Doc 3 for 3-grams: " + jacard_similarity(three_gram.get(1),three_gram.get(2)));
				System.out.println("JS between Doc 2 and Doc 4 for 3-grams: " + jacard_similarity(three_gram.get(1),three_gram.get(3)));
				System.out.println("JS between Doc 3 and Doc 4 for 3-grams: " + jacard_similarity(three_gram.get(2),three_gram.get(3)));
				System.out.println("AS between Doc 1 and Doc 2 for 3-grams: " + andberg_similarity(three_gram.get(0),three_gram.get(1)));
				System.out.println("AS between Doc 1 and Doc 3 for 3-grams: " + andberg_similarity(three_gram.get(0),three_gram.get(2)));
				System.out.println("AS between Doc 1 and Doc 4 for 3-grams: " + andberg_similarity(three_gram.get(0),three_gram.get(3)));
				System.out.println("AS between Doc 2 and Doc 3 for 3-grams: " + andberg_similarity(three_gram.get(1),three_gram.get(2)));
				System.out.println("AS between Doc 2 and Doc 4 for 3-grams: " + andberg_similarity(three_gram.get(1),three_gram.get(3)));
				System.out.println("AS between Doc 3 and Doc 4 for 3-grams: " + andberg_similarity(three_gram.get(2),three_gram.get(3)));
			}
			if (i == 2)
			{
				System.out.println("JS between Doc 1 and Doc 2 for 3-grams-words: " + jacard_similarity(three_gram_words.get(0),three_gram_words.get(1)));
				System.out.println("JS between Doc 1 and Doc 3 for 3-grams-words: " + jacard_similarity(three_gram_words.get(0),three_gram_words.get(2)));
				System.out.println("JS between Doc 1 and Doc 4 for 3-grams-words: " + jacard_similarity(three_gram_words.get(0),three_gram_words.get(3)));
				System.out.println("JS between Doc 2 and Doc 3 for 3-grams-words: " + jacard_similarity(three_gram_words.get(1),three_gram_words.get(2)));
				System.out.println("JS between Doc 2 and Doc 4 for 3-grams-words: " + jacard_similarity(three_gram_words.get(1),three_gram_words.get(3)));
				System.out.println("JS between Doc 3 and Doc 4 for 3-grams-words: " + jacard_similarity(three_gram_words.get(2),three_gram_words.get(3)));				
			}
		}
		
		//Ques 2(a)
		//min_hashing(three_gram.get(0) , three_gram.get(1));
	}
	
	public static  String Read_File(String file_name) throws FileNotFoundException  {
		@SuppressWarnings("resource")
		String entireFileText = new Scanner(new File(file_name)).useDelimiter("\\A").next();
		return entireFileText;

	}
	
	public static HashSet<String> build_2_gram (String data) throws IOException{
		File fout = new File("2_grams.txt");
		FileOutputStream fos = new FileOutputStream(fout);
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));
		
		HashSet<String> hash_set = new  HashSet<String>() ;
		for(int i = 1; i < data.length(); i++)
		{
			String current = data.substring(i-1, i+1);
			hash_set.add(current);
			bw.write(current);
			bw.newLine();
		}
		bw.close();
		return hash_set;
		
	}
	public static HashSet<String> build_3_gram (String data){
		HashSet<String> hash_set = new  HashSet<String>() ;
		for(int i = 2; i < data.length(); i++)
		{
			String current = data.substring(i-2, i+1);
			//System.out.println(current);
			hash_set.add(current);
		}
		return hash_set;		
	}
	public static HashSet<String> build_3_gram_words (String data) throws IOException{
		String[] parts = data.split(" ");
		File fout = new File("3_grams_words.txt");
		FileOutputStream fos = new FileOutputStream(fout);
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));
		HashSet<String> hash_set = new  HashSet<String>() ;
		for(int i = 2; i < parts.length; i++)
		{
			String current =  parts[i-2];
			current = current.concat(parts[i-1]);
			current = current.concat(parts[i]);	
			hash_set.add(current);
			
			bw.write(current);
			bw.newLine();			
		}
		bw.close();
		return hash_set;		
	}
	
	public static double jacard_similarity(Set<String>  set1 , Set<String> set2){
		int size1 = set1.size();
		int size2 = set2.size();
		HashSet<String> intersection = new HashSet<String>(set1); // use the copy constructor
		intersection.retainAll(set2);
		int size_intersection = intersection.size();
		double JS = (double)size_intersection/ (double)(size1 + size2 - size_intersection);
		return JS;		
	}
	public static double andberg_similarity(Set<String>  set1 , Set<String> set2){
		int size1 = set1.size();
		int size2 = set2.size();
		HashSet<String> intersection = new HashSet<String>(set1); // use the copy constructor
		intersection.retainAll(set2);
		double size_intersection = intersection.size();
		double size_union = size1 + size2 - size_intersection;
		double AS = size_intersection/(size_union + (size_union/size_intersection));
		return size_union;		
	}
	
	
	
	
	public static double min_hasing(Set<String>  set1 , Set<String> set2,int t) throws NoSuchAlgorithmException{
		double count = 0;
		BigInteger min[];
		Random randomGenerator = new Random();
		for(int i = 0 ;i < t ; i++){
			//int salt = randomGenerator.nextInt(1000000);;
			min = min_hash(set1,set2,i);// salt to change the hash function
			if (min[0].compareTo(min[1]) == 0)
				count = count +  1;				
		}		
		return count/t;		
	}
	
	public static BigInteger[] min_hash(Set<String>  set1 , Set<String> set2,int salt) throws NoSuchAlgorithmException{
		BigInteger min[] = new BigInteger[2];
		BigInteger min_1 = new BigInteger("FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF",16);
		BigInteger min_2 = new BigInteger("FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF",16);
		//SHA1 hashing
		MessageDigest digest = MessageDigest.getInstance("SHA1");
		//for set 1
		Iterator<String> iterator = set1.iterator();
		while(iterator.hasNext()){
			String element = (String) iterator.next();
			element = element + salt;
			byte[] output = digest.digest(element.getBytes()); //generating bytes for the element
			String hex = hexToString(output);
			BigInteger bi = new BigInteger(hex, 16);
			if (min_1.compareTo(bi)>0)
				   min_1 = bi;
		}
		//for set 2
		iterator = set2.iterator();
		while(iterator.hasNext()){
			String element = (String) iterator.next();
			element = element + salt;
			byte[] output = digest.digest(element.getBytes()); //generating bytes for the element
			String hex = hexToString(output);
			BigInteger bi = new BigInteger(hex, 16);
			if (min_2.compareTo(bi)>0)
				   min_2 = bi;
		}
		min[0] = min_1;
		min[1] = min_2;
		return min;	
	}
	
	private static String hexToString(byte[] output) {
	    char hexDigit[] = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
	            'A', 'B', 'C', 'D', 'E', 'F' };
	    StringBuffer buf = new StringBuffer();
	    for (int j = 0; j < output.length; j++) {
	        buf.append(hexDigit[(output[j] >> 4) & 0x0f]);
	        buf.append(hexDigit[output[j] & 0x0f]);
	    }
	    return buf.toString();

	}
	
	public static void min_hashing(Set<String>  set1 , Set<String> set2) throws NoSuchAlgorithmException{
		//int t[] = {10,50,100,250,500};
		double js[] = new double[1000];
		int counter = 0;
		for (int i = 0 ; i<= 1000 ; ){
			long time_start = System.currentTimeMillis();
			js[counter] = min_hasing(set1 , set2, i);
			long time_end = System.currentTimeMillis();
			System.out.println( i + "      " + js[counter] + "   " + (time_end - time_start) );
			counter = counter +1;
			i = i +20;
		}
		
	}
	

	
	
}
