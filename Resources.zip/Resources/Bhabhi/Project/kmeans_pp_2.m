function [centers] = kmeans_pp_2(data,data1,k)
    [n,d] = size(data);
    [~,d1] = size(data1);
    if d1 ~= 2
        return
    end
    %Array to keep track of center of clusters
    centers = zeros(k,d+d1);
    %randomly asign a data point as center of first cluster
    r= randi(n,1);
    centers(1,:) = [data(r,:) data1(r,:)];
    for i = 2:k
        weight = zeros(n,1);
        for j = 1:n
            x_j = data(j,:); %current_point intensity
            y_j = data1(j,:); %current point location
            c_j = centers(i-1,:); %center of cluster number i-1
            dist = sum((x_j-c_j(1,1:d)).^2) + sum((y_j-c_j(1,d+1:d+2)).^2); %euclidean distance square
            weight(j,1) = dist;
        end
        weight = weight / sum(weight);
        for j = 2:n
            weight(j,1) = weight(j-1,1) + weight(j,1);
        end
        %Choose a random number between 0 - 1
        r = rand(1);
        index = find(weight>=r);
        [nn,~] = size(index);
        while nn == 0
            r = rand(1);
            index = find(weight>=r);
            [nn,~] = size(index);
        end
        centers(i,:) = [data(index(1,1),:) data1(index(1,1),:)];
    end
end

