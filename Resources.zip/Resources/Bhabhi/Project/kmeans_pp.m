function [centers] = kmeans_pp(data,k)
    [n,d] = size(data);
    %Array to keep track of center of clusters
    centers = zeros(k,d);
    %randomly asign a data point as center of first cluster
    r= randi(n,1);
    centers(1,:) = data(r,:);
    for i = 2:k
        weight = zeros(n,1);
        for j = 1:n
            x_j = data(j,:); %current_point
            c_j = centers(i-1,:); %center of cluster number i-1
            dist = sum((x_j-c_j).^2); %euclidean distance square
            weight(j,1) = dist;
        end
        weight = weight / sum(weight);
        for j = 2:n
            weight(j,1) = weight(j-1,1) + weight(j,1);
        end
        %Choose a random number between 0 - 1
        r = rand(1);
        index = find(weight>=r);
        [nn,~] = size(index);
        while nn == 0
            r = rand(1);
            index = find(weight>=r);
            [nn,~] = size(index);
        end
        centers(i,:) = data(index(1,1),:);
    end
end

