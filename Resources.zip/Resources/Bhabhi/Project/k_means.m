close all;
clear; 
im = imread('113044.jpg');
figure()
imshow(im);
title('Input Image')


im1 = imread('113044.png');
%Building vectors for segmentation
[row, col, ~] = size(im);
im1 = double(im1)+1;
%im1 = im1/sum(sum(im1));

% [cy,cx]=ind2sub([ row,col],1:row*col);
% cx = cx';
% cy = cy';
k=5;

% rgb = [rgb cx cy];
% im_lab = [im_lab cx cy];
% im_gray = [im_gray cx cy];

%Perform k mean segmentation

%% On rgb colors


% rgb = double(im);
% rgb = reshape(rgb,row*col,3);  %n X 3 based on color
weights = reshape(im1,row*col,1);
weights = weights * 10;
%[centers] = kmeans_pp(rgb,k);

%[cluster_idx_rgb, ~] = kmean_ss(rgb,k,centers,weights);
% [cluster_idx_rgb, ~] = kmeans([rgb weights],k,'Distance','sqeuclidean','EmptyAction','drop');
% pixel_labels_rgb = reshape(cluster_idx_rgb,row,col);
% figure();
% imshow(pixel_labels_rgb, []);
% title('Image segmentation based on color in rgb space');
% colormap('gray');
% colorbar;



% [cluster_idx_rgb, ~] = kmean_ss(rgb,k);
% pixel_labels_rgb = reshape(cluster_idx_rgb,row,col);
% figure();
% imshow(pixel_labels_rgb, []);
% title('Image segmentation based on color in rgb space');
% colormap('jet');
% colorbar;





%% On lab space colors
% 
% % RGB values to CIE 1976 L*a*b* values.
cform = makecform('srgb2lab');
im_lab = applycform(im,cform);
figure()
imshow(im_lab);
title('Input Image in Lab color space')

im_lab = double(im_lab(:,:,2:3));
im_lab = reshape(im_lab,row*col,2); % n X 2  based on color

%intensity based clustering
[cluster_idx_lab, ~] = kmeans([im_lab weights],k,'Distance','sqeuclidean','EmptyAction','drop');
pixel_labels_lab = reshape(cluster_idx_lab,row,col);
figure();
imshow(pixel_labels_lab, []);
title('Image segmentation based on intensity in lab color space');
colormap('gray');
colorbar;
% % 
% 
% %intensity + location
% [cluster_idx_lab, ~] = kmean_ss_2(im_lab,[cx cy],k,0.7,0.3);
% pixel_labels_lab = reshape(cluster_idx_lab,row,col);
% figure();
% imshow(pixel_labels_lab, []);
% title('Image segmentation based on intensity in lab color space');
% colormap('jet');
% colorbar;

for i = 1:row
    for j = 1:col
        if pixel_labels_lab(i,j) == 2
            pixel_labels_lab(i,j) = 3;
%           elseif pixel_labels_lab(i,j) == 1
%               pixel_labels_lab(i,j) =5;  
%         elseif pixel_labels_rgb(i,j) == 3
%             pixel_labels_rgb(i,j) =4;    
        end
    end
end


% %Thresholding
[ thresh_im ] = threshold_ss( pixel_labels_lab,1 );
figure();
imshow(thresh_im, []);
title('Image segmentation based on color in rgb space thresholded');
colormap('gray');
colorbar;

%% On gray Scale Colors

% %Convert RGB to gray scale for intensities
% im_gray = rgb2gray(im);
% figure()
% imshow(im_gray)
% title('Input Image in gray scale')
% k = 3;
% 
% im_gray = double(im_gray);
% im_gray = im_gray(:);   % n X 1  based on intensity



% [cluster_idx_gray, ~] = kmeans(im_gray,k,'Distance','sqeuclidean','EmptyAction','drop');
% pixel_labels_gray = reshape(cluster_idx_gray,row,col);
% figure();
% imshow(pixel_labels_gray, []);
% title('Image segmentation based on intensity in gray scale');
% colormap('jet');
% colorbar;







