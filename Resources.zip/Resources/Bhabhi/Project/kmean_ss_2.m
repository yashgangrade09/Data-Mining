function [ clusters,centers ] = kmean_ss_2( data,data1,k ,alpha,beta)
    [n,d] = size(data); %n: number of data points. d: dimension
    [~,d1] = size(data1);
    if d1 ~= 2
        return
    end
    clusters = zeros(n,1); %specify cluster number for each data point    
    %initialize centers
    %using k means ++ to intialize centers
    [centers] = kmeans_pp_2(data,data1,k);
    while(1)
        count = 0;
        %Assigning each point to a cluster
        for i = 1:n
            %current point
            x_j = data(i,:); %current_point
            y_j = data1(i,:); %current point location            
            M = Inf(1);
            cluster = -1;
            for j = 1:k
                c_j = centers(j,:);
                dist =alpha * ( sum((x_j-c_j(1,1:d)).^2)) + beta * ( sum((y_j-c_j(1,d+1:d+2)).^2)); %euclidean distance square
                if dist < M
                    M = dist;
                    cluster = j;
                end
            end
            if clusters(i,1) ~= cluster
                count = count + 1;
                clusters(i,1) = cluster;
            end
        end
        %Updating the cluster centers
        centers = zeros(k,d+d1);
        cluster_count = zeros(k,1);
        for i = 1:n
            cluster = clusters(i,1);
            centers(cluster,:) = centers(cluster,:) + [data(i,:) data1(i,:)];
            cluster_count(cluster) = cluster_count(cluster) + 1;
        end
        for j = 1:k
            centers(j,:) = centers(j,:)/cluster_count(j);
        end
        if count < (0.01*n)
            break;
        end
        
    end


end

