%Reading the dicom files
clear;
close all;
info = dicominfo('n16_1x_full\n16_1x_full200.dcm');
Y = dicomread(info);
figure, imshow(Y);
imcontrast;
J = histeq(Y);
figure,imshow(J);colormap('gray');
colorbar;

figure,imhist(J);


%Building vectors for segmentation
[row, col, ~] = size(J);

J =double(J);
X= reshape(J,row*col,1); 



centers = unique(J);
[k,~] = size(centers);

[cluster_idx, ~] = kmean_ss( X,k,centers );
pixel_labels = reshape(cluster_idx,row,col);
figure();
imshow(pixel_labels, []);
title('Image segmentation based on color in rgb space');
colormap('gray');
colorbar;

for i = 1:row
    for j = 1:col
        if pixel_labels(i,j) == 6 || pixel_labels(i,j) == 5
            pixel_labels(i,j) = 1;
        else
            pixel_labels(i,j) = 0;
        end
    end
end

figure();
imshow(pixel_labels, []);
title('Image segmentation based on color in rgb space');
colormap('gray');
colorbar;
