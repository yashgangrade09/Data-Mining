close all;
clear; 
im = imread('113044.jpg');
figure()
imshow(im);
title('Input Image')


%Building vectors for segmentation
[row, col, ~] = size(im);
k = 5;
im1 = imread('113044.png');
im1 = double(im1)+1;
weights = reshape(im1,row*col,1);
weights = weights * 10;
%% On rgb colors
cform = makecform('srgb2lab');
im_lab = applycform(im,cform);
figure()
imshow(im_lab);
title('Input Image in Lab color space')

im_lab = double(im_lab(:,:,2:3));
im_lab = reshape(im_lab,row*col,2); % n X 2  based on color



%  rgb = double(im);
% rgb = reshape(rgb,row*col,3);  %n X 3 based on color

rgb = im_lab;
[centers] = kmeans_pp([rgb weights],k);
[label, model, llh] = emgm([rgb weights]', centers');
cluster_idx_rgb = label';
pixel_labels_rgb = reshape(cluster_idx_rgb,row,col);
figure();
imshow(pixel_labels_rgb, []);
title('Image segmentation based on color in rgb space');
colormap('gray');
colorbar;

[ thresh_im ] = threshold_ss( pixel_labels_rgb,1 );
figure();
imshow(thresh_im, []);
title('Image segmentation based on color in rgb space thresholded');
colormap('gray');
colorbar;