function [ thresh_im ] = threshold_ss( im,iter )
    [row,col] = size(im);
    thresh_im = im;
    for k  = 1:iter
        for i = 2:row-1
            for j = 2:col-1
                neigh = im(i-1:i+1,j-1:j+1);
                %find unique elements in the neighbourhood
                temp = unique(neigh);
                %count the frequency of each unique label.
                count = [temp,histc(neigh(:),temp)];
                label = find(max(count(:,2)));
                thresh_im(i,j) = count(label,1);
            end
        end
        im = thresh_im;
    end
end