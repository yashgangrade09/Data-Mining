im = imread('grad_x.pgm')
imshow(im)
im = rgb2gray(im);
imwrite(im,'test.pgm')