%row gradient
function [Ux] = gradient_x(U)
    [rows cols] = size(U);
    Ux = zeros(rows,cols);
    for i = 1:rows
        for j = 1:cols
            if i == rows
                Ux(i,j) = 0;
            else
                Ux(i,j) = U(i+1,j) - U(i,j) ;
            end
        end
    end
end