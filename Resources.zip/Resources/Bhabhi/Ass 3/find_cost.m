function [ center_cost , mean_cost] = find_cost( data,centers )
    center_cost = 0;
    mean_cost = 0;
    [n,d] = size(data);
    index = -1;
    
    for i = 1:n
        x_i = data(i,2:d-1);
        k_i = data(i,d);
        c = centers(k_i,:);
        dist = sqrt(sum((x_i-c).^2));
        if dist > center_cost
            center_cost = dist;
            index = i;
        end
        mean_cost = mean_cost + dist^2;
    end
end

