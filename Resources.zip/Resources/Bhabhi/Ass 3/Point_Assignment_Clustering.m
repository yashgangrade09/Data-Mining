
%Read the data 
data = read_file('C2.txt',3);
k = 3;
%Plot the data
figure ()
scatter(data(:,2),data(:,3));
title('Inital Data')
labels = num2str(data(:,1),'%d');    
text(data(:,2), data(:,3), labels, 'horizontal','left', 'vertical','bottom')
% 
% %Gonzalez 
[ data_g,centers_g ] = Gonzalez_Greedy_Algorithm( data , k);
[ center_cost_g , mean_cost_g] = find_cost( data_g,centers_g );
plot_data( data_g, centers_g ,'Gonzalez Greedy Algorithm For Clustering' );
% 
% %K-means Ques 2(b) 1
%%initial centers
centers = data(1:3,2:3);
[data_i,new_centers_i] = kmeans_1(data,centers);
[ center_cost , mean_cost] = find_cost( data_i,new_centers_i ); 
plot_data( data_i, new_centers_i ,'Index Initialization based K means clustering' ); 
disp(mean_cost)                
% 
% 
% %initial centers from Gonzalez Ques 2(b) 2
                  
[data_g,new_centers_g] = kmeans_1(data,centers_g);
[ center_cost_k_g , mean_cost_k_g] = find_cost( data_g,new_centers_g ); 
plot_data( data_g, new_centers_g ,'Gonzalez Initialization based K means clustering' ); 
disp(mean_cost_k_g)








