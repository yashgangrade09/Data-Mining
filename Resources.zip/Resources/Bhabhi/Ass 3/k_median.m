clear all
close all
data = read_file('C3.txt',6);
[n,d] = size(data);
k = 5;
[ data_g,centers ] = Gonzalez_Greedy_Algorithm( data , k);
[ data_k, new_centers] = kmedians_1( data, centers );
[ mean_cost_kg] = find_cost_median( data_k,new_centers );
disp(mean_cost_kg);

centers = data(1:k,2:d);
[ data_k, new_centers] = kmedians_1( data, centers );
[ mean_cost_ki] = find_cost_median( data_k,new_centers );
disp(mean_cost_ki);

iter = 1000;
cost = zeros(iter,1);
final_centers = zeros(k,d-1);
M = Inf;
for i = 1:iter
    [ data_kp, centers ] = kmeans_pp( data,k );
    [ data_k_p, new_centers] = kmedians_1( data, centers );
    [ mean_cost_kp] = find_cost_median( data_k_p,new_centers );
    disp(mean_cost_kp);
    cost(i,1) = mean_cost_kp;
    if mean_cost_kp < M
        M = mean_cost_kp;
        final_centers = new_centers;
    end
end
iter = 1000;
cost1 = zeros(iter,1);
final_centers1 = zeros(k,d-1);
M1 = Inf;
for i = 1:iter
    Int = randi([1 n],k,1);
    centers = data(Int,2:d);
    [ data_k_p, new_centers] = kmedians_1( data, centers );
    [ mean_cost_kp] = find_cost_median( data_k_p,new_centers );
    disp(mean_cost_kp);
    cost1(i,1) = mean_cost_kp;
    if mean_cost_kp < M1
        M1 = mean_cost_kp;
        final_centers1 = new_centers;
    end
end