im = imread('42049.jpg');
im = rgb2gray(im);
im = double(im);
[nrows,ncols] = size(im);
%convert matrix image into a vector
data = im(:);
%Getting the row and col
[cy,cx]=ind2sub([nrows,ncols],1:nrows*ncols);

%scale the image to start from 1
mini = min(data);
data = data - mini +1;
%number of clusters
k = 3;

%Initialize cluster centers using k means++
[ data_k, centers_k ] = kmeans_pp( data,k );
%Perform k means
[ idx, new_centers ] = kmeans( data,k,'Start', centers_k,'EmptyAction','drop' ); 
pixel_labels = reshape(cluster_idx,nrows,ncols);

figure();
imshow(pixel_labels, []);
colormap('jet');
colorbar;