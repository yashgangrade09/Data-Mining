function [ data, centers ] = kmeans_pp( data,k )
    [n,d] = size(data);
    %Array to keep track of center of clusters
    centers = zeros(k,d-1);
    %assign it as the first centroid
    centers(1,:) = data(1,2:d);
    for i = 2:k
        weight = zeros(n,1);
        for j = 1:n
            x_j = data(j,2:d); %current_point
            c_j = centers(i-1,:); %center of cluster number i-1
            dist = sum((x_j-c_j).^2); %distance square
            weight(j,1) = dist;
        end
        weight = weight / sum(weight);
        for j = 2:n
            weight(j,1) = weight(j-1,1) + weight(j,1);
        end
        %Choose a random number between 0 - 1
        r = rand(1);
        index = find(weight>=r);
        [nn,~] = size(index);
        while nn == 0
            r = rand(1);
            index = find(weight>=r);
            [nn,~] = size(index);
        end
        centers(i,:) = data(index(1,1),2:d);
    end
    data = [data zeros(n,1)];
    for i = 1:n
        x_i = data(i,2:d); %current_point
        M = Inf(1);
        for j = 1:k
            dist = sqrt(sum((x_i-centers(j,:)).^2));
            if dist < M
                M = dist;
                cluster = j ;
            end
        end
        data(i,d+1) = cluster;
    end
end

