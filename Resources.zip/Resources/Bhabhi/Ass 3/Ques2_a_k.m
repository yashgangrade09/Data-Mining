%Read the data 
data = read_file('C2.txt',3);
k = 3;
iter = 1000;
cost = zeros(iter,1);
count_same = 0;

%Find the G A centers
[ data_g,centers_g ] = Gonzalez_Greedy_Algorithm( data , k);

for i = 1:iter
    [ data_k, centers_k ] = kmeans_pp( data,k );
    [ center_cost , mean_cost] = find_cost( data_k,centers_k );
    cost(i,1) = mean_cost;
    
    %Check if the centers are same as GA centers
    if (abs(centers_k(1,1)+40)<0.001) && (abs(centers_k(1,2)-40)<0.001)
        count_same = count_same +1;
    else
        if (abs(centers_k(2,1)+40)<0.001) && (abs(centers_k(2,2)-40)<0.001)
            count_same = count_same +1;
        else
            if (abs(centers_k(3,1)+40)<0.001) && (abs(centers_k(3,2)-40)<0.001)
                count_same = count_same +1;
            end
        end        
    end
    
    %Plotting centers with data
    %plot_data( data_k, centers_k ,i );
end
figure();
cdfplot(cost)