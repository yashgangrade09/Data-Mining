function plot_data( data, centers , t )
    figure()
    scatter(data(:,2),data(:,3),25,data(:,4),'Filled');
    title(t);
    hold on;
    [k,~] = size(centers);
    scatter(centers(:,1),centers(:,2),25,'k','filled')
    textCell = arrayfun(@(x,y) sprintf('(%3.2f, %3.2f)',x,y),centers(:,1),centers(:,2),'un',0);
    for ii = 1:k
            text(centers(ii,1)+.05, centers(ii,2)+.05,textCell{ii},'FontSize',8)        
    end 
end

