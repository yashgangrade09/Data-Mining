function [ data, new_centers ] = kmeans_1( data, centers )
    [n,cols] = size(data);
    [k,~] = size(centers);
    %Assigning all the points to no cluster
    data(:,cols+1)= zeros(n,1); 
    iter = 0;
    while(1)
        count = 0;
        for i = 1:n
            %current point
            x_i = data(i,2:3); %current_point
            M = Inf(1);
            cluster = -1;
            for j = 1:k
                dist = sqrt((x_i(1,1) - centers(j,1))^2 + (x_i(1,2) - centers(j,2))^2);
                if dist < M
                    M = dist;
                    cluster = j;
                end
            end
            if data(i,4) ~= cluster
                count = count + 1;
                data(i,4) = cluster;
            end            
        end
        %updating the centers
        new_centers = zeros(k,2);
        cluster_count = zeros(k,1);
        for i = 1:n
            cluster = data(i,4);
            new_centers(cluster,1:2) = new_centers(cluster,1:2) + data(i,2:3);
            cluster_count(cluster) = cluster_count(cluster) + 1;
        end
        for j = 1:k
            new_centers(j,1) = new_centers(j,1)/cluster_count(j);
            new_centers(j,2) = new_centers(j,2)/cluster_count(j);
        end
        if count == 0
            break;
        end
        iter = iter +1;
        [ ~ , energy(iter,1)] = find_cost(data,new_centers);
        if iter ~= 1 && energy(iter-1,1) == energy(iter,1)
            break;
        end
    end
    figure();
    plot(energy);
end

