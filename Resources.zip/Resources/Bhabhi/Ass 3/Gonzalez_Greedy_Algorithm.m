function [ data,centers ] = Gonzalez_Greedy_Algorithm( data , k)
    [n,cols] = size(data);
    %Array to keep track of center of clusters
    centers = zeros(k,cols-1);
    %Assigning all the points to cluster 1
    data(:,cols+1)= ones(n,1);
    %Assign first point as center of cluster 1
    centers(1,:) = data(1,2:cols);
    for i = 2:k
        M = 0;
        ci = 1;
        for j = 1:n
            %distance between the current point and center of cluster to
            %which it belongs
            x_j = data(j,2:cols); %current_point
            c_j = centers(data(j,cols+1),:); %center of cluster to which it belongs
            dist = sqrt(sum((x_j-c_j).^2));
            if dist > M
                M = dist;
                ci = j;
            end
        end
        c_i = data(ci,2:cols); %new proposed center
        for j = 1:n
            x_j = data(j,2:cols); %current_point
            c_j = centers(data(j,cols+1),:); %center of cluster to which it belongs            
            dist1 = sqrt(sum((x_j-c_j).^2));
            dist2 = sqrt(sum((x_j-c_i).^2));
            if dist1 > dist2
                data(j,cols+1) = i;
            end           
        end
        centers(i,:) = c_i;
    end
end

