function [ data ] = read_file( file_name , col_count)
    fid = fopen(file_name);
    temp = fscanf(fid, '%f');
    [n,~] = size(temp);
    n = n/col_count; %number of data points
    data = zeros(n,col_count);
    for i = 1:n
        j = i*col_count;
        for k = 1:col_count
            data(i,k)= temp(j-(col_count-k),1);
        end
    end
end

