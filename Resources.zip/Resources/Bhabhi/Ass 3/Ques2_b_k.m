%Read the data
clear all;
close all;
data = read_file('C3.txt',6);
k = 4;
iter = 10;
cost = zeros(iter,1);
count_same = 0;
count = 0;
M = Inf;
[n,d] = size(data);
for i = 1:iter
    [ data_k, centers_k ] = kmeans_pp( data,k );
    %plot_data( data_k, centers_k ,i );
    [ idx, new_centers ] = kmeans( data(:,2:d),k,'Start', centers_k,'EmptyAction','drop' ); 
    [ center_cost , mean_cost] = find_cost( [data idx],new_centers );
    cost(i,1) = mean_cost;

%     cluster1_s = find(data_k(:,4) == 1);
%     cluster1_e = find(idx(:,1) == 1);
%     [size1_s,~] = size(cluster1_s);
%     [size1_e,~] = size(cluster1_e);
%     cluster2_s = find(data_k(:,4) == 2);
%     cluster2_e = find(idx(:,1) == 2);
%     [size2_s,~] = size(cluster2_s);
%     [size2_e,~] = size(cluster2_e);
%     cluster3_s = find(data_k(:,4) == 3);
%     cluster3_e = find(idx(:,1) == 3);                    
%     [size3_s,~] = size(cluster3_s);
%     [size3_e,~] = size(cluster3_e);
%    
%     if (size1_s == size1_e) && (size2_s == size2_e) &&  (size3_s == size3_e)
%         count = count +1;        
%     else
%         temp = [size1_s size1_e size2_s size2_e size3_s size3_e];
%         disp(temp);
%         %plot_data( [data idx], new_centers ,i );
%         %plot_data( data_k, centers_k ,i );
%     end
%     if (size2_s == size2_e)
%         count_same = count_same +1;
%     end
    if mean_cost < M
        M = mean_cost;
        final_centers = new_centers;
    end
        
end
figure();
cdfplot(cost)