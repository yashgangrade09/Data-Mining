function [ centers] = find_centers(data)
    [k,~] =size(unique(data(:,4)));
    centers = zeros(k,2);
    count = zeros(k,1);
    [n,~] = size(data);
    for i = 1:n
        cluster = data(i,4);
        centers(cluster,:) = centers(cluster,:) + data(i,2:3);
        count(cluster,:) = count(cluster,:) + 1;
    end
    for i = 1:k
        centers(i,1) = centers(i,1)/count(i,1);
        centers(i,2) = centers(i,2)/count(i,1);
    end

end

