function [ mean_cost] = find_cost_median( data,centers )
    mean_cost = 0;
    [n,d] = size(data);
    for i = 1:n
        x_i = data(i,2:d-1);
        k_i = data(i,d);
        c = centers(k_i,:);
        dist = sum(abs(x_i - c));
        mean_cost = mean_cost + dist;
    end
end


