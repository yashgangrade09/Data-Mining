function [ data, new_centers ] = kmedians_1( data, centers )
    [n, col] = size(data);
    [k, d] = size(centers);
    %Assigning all the points to no cluster
    data(:,col+1)= zeros(n,1); 
    iter = 0;
    while(1)
        %count the number of elements assigned to new cluster in this
        %iteration
        count = 0;
        %Find new clusters assignment
        for i = 1:n
            x_i = data(i,2:col); %current point
            M = Inf(1);
            cluster = -1;
            for j = 1:k
                %Find manhatton distance netween the point and current
                %cluster center
                dist = sum(abs(x_i - centers(j,:)));
                if dist < M
                    M = dist;
                    cluster = j;
                end
            end
            if data(i,col+1) ~= cluster
                count = count + 1;
                data(i,col+1) = cluster;
            end
        end
        %Finding new cluster centers
        %New cluster centers will be the median of given cluster
        new_centers = zeros(k,d);
        for j = 1: k
            temp = find(data(:,col+1) == j);
            new_centers(j,:) = median(data(temp,2:col));
        end
        iter = iter + 1;
        if count == 0
            break;
        end
    end
end

