%Read the data 
data = read_file('C1.txt',3);
%Plot the data
figure (1)
scatter(data(:,2),data(:,3),50,'b','filled');
labels = num2str(data(:,1),'%d');    
text(data(:,2), data(:,3), labels, 'horizontal','left', 'vertical','bottom')

%Calculate euclidean distance distance-matrix
d = pdist(data(:,2:3));
%distance_matrix = squareform(d);

%Perform Hierarchical Clustering
%single
Z_s = linkage(d,'single');
%Complete
Z_c = linkage(d,'complete');
%Mean
Z_m = linkage(d,'centroid');

%Visualize Linkage
% figure(2);
% dendrogram(Z_s)
% title('Single Linkage')
% figure(3);
% dendrogram(Z_c)
% title('Complete Linkage')
% figure(4);
% dendrogram(Z_m)
% title('Mean Linkage')

%Perform CLustering
c_s = cluster(Z_s,'maxclust',4);
c_c = cluster(Z_c,'maxclust',4);
c_m = cluster(Z_m,'maxclust',4);

%plotting
figure();
scatter(data(:,2),data(:,3),50,c_s,'filled');
text(data(:,2), data(:,3), labels, 'horizontal','left', 'vertical','bottom')
title('Single Link')
figure();
scatter(data(:,2),data(:,3),50,c_c,'filled');
text(data(:,2), data(:,3), labels, 'horizontal','left', 'vertical','bottom')
title('Complete Link')
figure();
scatter(data(:,2),data(:,3),50,c_m,'filled');
text(data(:,2), data(:,3), labels, 'horizontal','left', 'vertical','bottom')
title('Mean Link')

%Calculating cost

%find centroids
new_data = [data c_s];
centers = find_centers(new_data);
[ center_cost_s , mean_cost_s] = find_cost( new_data,centers );

new_data = [data c_c];
centers = find_centers(new_data);
[ center_cost_c , mean_cost_c] = find_cost( new_data,centers );

new_data = [data c_m];
centers = find_centers(new_data);
[ center_cost_m , mean_cost_m] = find_cost( new_data,centers );


