function [k] = generate_random_cc(n)
    mapObj1 = containers.Map('KeyType','int32','ValueType','int32');
    mapObj2 = containers.Map('KeyType','int32','ValueType','int32');
    
    
    k = 0;
    while(1)
        k = k+1;
        temp = floor(n * rand(1));
        if (isKey(mapObj1,temp))
            mapObj1(temp) = mapObj1(temp) + 1;
            if(~isKey(mapObj2,temp))
                mapObj2(temp) = 1;
            end
        else
            mapObj1(temp) = 1;
        end
        size1 = size(keys(mapObj1));
        size2 = size(keys(mapObj2));
        if (size1(1,2) == n && size2(1,2) == n)
            return;
        end   
    end
end