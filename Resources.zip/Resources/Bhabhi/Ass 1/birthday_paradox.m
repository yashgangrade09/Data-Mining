%Birthday Paradox

%(b)
% Repeat the experiment m = 300 times, and record for each how many random trials this
%took. Plot this data as a cumulative density plot where the x-axis records the number of trials required k,
%and the y-axis records the fraction of experiments that succeeded (a collision) after k trials. The plot should
%show a curve that starts at a y value of 0, and increases as k increases, and eventually reaches a y value of 1.

function[emprical_estimated_k,total_time]= birthday_paradox(m,n)
    start_time = clock;
    store_k = zeros(m,1);
    for i = 1 : m
        store_k(i,1) = generate_random(n);
    end
    figure(1);    
    title('Cumulative Density Plot');
    cdfplot(store_k);
    emprical_estimated_k = sum(store_k)/m;
    end_time = clock;
    total_time = etime(end_time,start_time);

end

%birthday_paradox(10000,1000000)
%1.2564e+003