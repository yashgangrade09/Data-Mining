%Birthday Paradox

%(a)
% generate random integer numbers drawn from a uniform distribution in 
% interval [1,n]. Here n= 3000
%k -> number of independent trials after we get a match.

function [k] = generate_random(n)
    mapObj = containers.Map('KeyType','int32','ValueType','int32');
    k = 0;
    while(1)
        temp = floor(n * rand(1));
        if (isKey(mapObj,temp))
            return;
        end
        mapObj(temp) = 1;
        k = k+1;
    end
end
        
