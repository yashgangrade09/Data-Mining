function[emprical_estimated_k,total_time]= Coupon_Collectors(m,n)
    start_time = clock;
    store_k = zeros(m,1);
    for i = 1 : m
        store_k(i,1) = generate_random_cc(n);
    end
    end_time = clock;
    total_time = etime(end_time,start_time);
    
    figure(1);    
    title('Cumulative Density Plot');
    cdfplot(store_k);
    emprical_estimated_k = sum(store_k)/m;
    
end