load M.dat

t = 512;
qo = [1 zeros(1,9)]';
qo_new = [0.1 0.1 0.1 0.1 0.1 0.1 0.1 0.1 0.1 0.1]';
to = 50;

% q = zeros(10,1);
% q(10)=1;
% %Method 3
% for i = 1:200
%     temp = M*q;
%     index = find(temp == max(temp));
%     q = zeros(10,1);
%     q(index) = 1;
% end
% count = zeros(10,1);
% for i = 1:800
%     temp = M*q;
%     index = find(temp == max(temp));
%     count(index) = count(index) + 1;
%     q = zeros(10,1);
%     q(index) = 1;
% end
% disp(count/sum(count));



%find (M^t * qo)
%% method 1
Mt = M;
for i = 1:6
    Mt = Mt * Mt;
end
qf = Mt * qo_new;
%% method 2
q = qo_new;
for i = 1:64
    qf1 = M * q;
    q = qf1;
end

%% method 3



%% method 4
[V,D] = eigs(M)
